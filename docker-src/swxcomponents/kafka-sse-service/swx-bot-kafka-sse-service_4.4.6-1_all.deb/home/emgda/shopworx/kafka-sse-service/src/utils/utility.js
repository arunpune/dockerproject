const config = require('../../config/config.json')
const EventEmitter = require('eventemitter3');
const bunyan = require('bunyan');
const axios = require('axios');

const eventEmitter = new EventEmitter();

/** @constant {object} EVENTS_CONSTANTS constant obj to map events. */
const EVENTS_CONSTANTS = {
    ASM : "asm",
    ALERT : "alert",
    DEVICE : "device",
    PROCESS : "process",
}

/** @constant {number} INVALID_PAYLOAD_IN_REQUEST http status for invalid payload in request. */
const INVALID_PAYLOAD_IN_REQUEST = 400;

/** @constant {number} INTERNAL_SERVER_ERROR http status for internal server error. */
const INTERNAL_SERVER_ERROR = 500;

/** @constant {Object} SSE_RESPONSE_HEADER response header for sever-sent events. */
const SSE_RESPONSE_HEADER = {
    'Connection': 'keep-alive',
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'X-Accel-Buffering': 'no'
};

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'utility',
    level: config.logLevel
});

/** @constant {Object} */
const DATA_TYPE = {
    STRING: "string",
    NUMBER: "number",
    BOOLEAN: "boolean",
    OBJECT: "object"
};

/**
 * Send error bak to the user in response.
 * 
 * @param {object} res 
 * @param {object} status 
 * @param {string} errorMessage 
 * @param {number} errorCode 
 */
const sendError = (res, status, errorMessage, errorCode) => {
    logger.error('Error identifed. ' + JSON.stringify(errorMessage));
    res.status(status);
    const payload = { errorMessage, errorCode };
    res.send(JSON.stringify(payload));
}

/**
 * Get emitter.
 */
const getEmitter = () => {
    return eventEmitter;
}

/**
 * Get Asset URL.
 */
const getMyDetailsURL = () => {
    const URL = `http://${config.server.hostname}:${config.server.port}/server/users/mydetails`;
    logger.trace(`getMyDetailsURL: ${URL}`);
    return URL;
}

/**
 * Method to check if plugid in 2 object compared are matching.
 * 
 * @param {object} jsonData 
 * @param {object} results 
 */
const isSamePlugID = (jsonData, results) => {
    const myPlugId = `${jsonData.customerId}-${jsonData.siteId}`;
    const requestPlugId = `${results.customer.id}-${results.activeSiteId}`;
    const bool = myPlugId === requestPlugId;
    logger.trace(`Comparing PlugID: ${myPlugId} === ${requestPlugId} = ${bool}`);
    return bool;
}

/**
 * Stream events to give source.
 * 
 * @param {object} data 
 * @param {object} results 
 * @param {object} res 
 * @param {string} eventName 
 */
const streamEvent = (data, results, res,eventName) => {
    let jsonData = {};
    try {
        jsonData = JSON.parse(data);
    } catch (error) {
        logger.error(`Data received for publishing on SSE was not JSON: ${JSON.stringify(data)}`);
        return;
    }
    logger.trace(`Data received | emitter name : ${eventName}`);
    if (eventName === EVENTS_CONSTANTS.PROCESS) {
        logger.trace("Writing Data.");
        res.write('retry: 500\n');
        res.write(`event: ${jsonData.substationid}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
    } else if (eventName !== EVENTS_CONSTANTS.DEVICE && isSamePlugID(jsonData, results)) {
        logger.trace("Writing Data.");
        res.write('retry: 500\n');
        res.write(`event: ${jsonData.type}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
    } else if (eventName === EVENTS_CONSTANTS.DEVICE) {
        logger.trace("Writing Data.");
        res.write('retry: 500\n');
        res.write(`event: ${jsonData.deviceid}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
    }  else {
        logger.info(`Returning as plug ids did not match.`);
    }
}

/**
 * Set event listener.
 * 
 * @param {string} eventName 
 * @param {object} req 
 * @param {object} res 
 * @param {object} results 
 */
const setEventListener = (eventName, req, res, results) => {
    getEmitter().on(eventName, (data) => {
        streamEvent(data, results, res, eventName);
    });
    req.on("close", () => { logger.error('Connection closed'); });
    req.on("end", () => { logger.error('Connection ended'); });
    req.on("timout", () => { logger.error('Connection ended for plugID'); });
    req.on("error", (e) => { logger.error(`Connection error occured for plugID: ${JSON.stringify(e)}`); });
}

/**
 * Authenticate the user who has request for SSE.
 * 
 * @param {string} eventName 
 * @param {object} req 
 * @param {object} res 
 */
const authenticate = async (eventName, req, res) => {
    logger.trace('Server hit.');
    logger.error('Authenticating request.');
    // get my details
    logger.trace(`Request headers: + ${JSON.stringify(req.headers)}`);
    const cookie = req.headers.cookie;
    //Cookie: sessionId=C25275CACF9808FA6DF18B8F80BDF616.tomcat1; locale=zhHans
    logger.trace(`Cookie: ${cookie}`);
    const splittedStr = cookie.split(';');
    let index = splittedStr.findIndex(element => element.includes("sessionId"));
    if(index < 0) {
        sendError(res, INVALID_PAYLOAD_IN_REQUEST, "Session Id not identified.", "INVALID_SESSION");
        return;
    }
    const newCookieValue = splittedStr[index];
    if (!newCookieValue || newCookieValue.split('=').length !== 2) {
        sendError(res, INVALID_PAYLOAD_IN_REQUEST, "Invalid session identified.", "INVALID_SESSION");
        return;
    }
    const sessionId = newCookieValue.split('=')[1];
    logger.trace(`Session ID: ${sessionId}`);
    const cookieString = "JSESSIONID=" + sessionId + "; sessionId=" + sessionId + ";";
    const response = await axios.get(getMyDetailsURL(), {headers : { 'Cookie' : cookieString , 'sessionId' : sessionId}}, { withCredentials : true}).catch((error) => {
        logger.error(`Error while getting my details from server: ${JSON.stringify(error)}`);
    });
    if (!response) {
        sendError(res, INTERNAL_SERVER_ERROR, "Some error occured at server.", INTERNAL_SERVER_ERROR);
        return;
    }
    logger.trace('Some response identified from server.');
    if (response.data.errors) {
        sendError(res, INTERNAL_SERVER_ERROR, response.data.errors, INTERNAL_SERVER_ERROR);
        return;
    }
    res.writeHead(200, SSE_RESPONSE_HEADER);
    const results = response.data.results;
    logger.trace(`Response identified from server: ${JSON.stringify(results)}`);
    setEventListener(eventName, req, res, results);
}

/**
 * Handle ASM request.
 * 
 * @param {object} req 
 * @param {object} res 
 */
const handleAsmRequest  = async (req, res) => {
    authenticate(EVENTS_CONSTANTS.ASM, req, res);
}

/**
 * Handle alert request.
 * 
 * @param {object} req 
 * @param {object} res 
 */
const handlerAlertRequest = async (req, res) => { 
    authenticate(EVENTS_CONSTANTS.ALERT, req, res);
}

/**
 * Handle process request.
 * 
 * @param {object} req 
 * @param {object} res 
 */
 const handlerProcessRequest = async (req, res) => { 
    authenticate(EVENTS_CONSTANTS.PROCESS, req, res);
}

/**
 * Handle device request.
 * 
 * @param {object} req 
 * @param {object} res 
 */
const handlerDeviceRequest = async (req, res) => {
    res.writeHead(200, SSE_RESPONSE_HEADER);
    setEventListener(EVENTS_CONSTANTS.DEVICE, req, res, null);
}

/**
 * Checks if give configuration parameter exists with given data types. If no then exit node js service 
 * pointing deficiency in perticular parameter.
 * 
 * @param {string} configParam 
 * @param {string} dataType 
 */
const checkIfExists = (configParam, configParamString, dataType) => {
    // check if configuration parameter exists in configuration file.
    if (typeof configParam != 'boolean' && !configParam) {
        logger.fatal(`Configuration parameter not set: ${configParamString}. Exiting...`);
        process.exit(1);
    }
    // check if configuration parameter has valid data type.
    if (typeof configParam != dataType) {
        logger.fatal(`Data type for configuration parameter ${configParamString} must be: ${dataType}. Exiting...`);
        process.exit(1);
    }
}

/**
 * validate the configuration parameter is valid with given conditions
 */
const validateConfigfileParameters = () => {
    checkIfExists(config, "config", DATA_TYPE.OBJECT);

    checkIfExists(config.server, "config.server", DATA_TYPE.OBJECT);
    checkIfExists(config.server.hostname, "config.server.hostname", DATA_TYPE.STRING);
    checkIfExists(config.server.port, "config.server.port", DATA_TYPE.NUMBER);

    checkIfExists(config.logLevel, "config.log.logLevel", DATA_TYPE.STRING);

    checkIfExists(config.kafka, "config.kafka", DATA_TYPE.OBJECT);
    
    checkIfExists(config.kafka, "config.kafka", DATA_TYPE.OBJECT);
    checkIfExists(config.kafka.brokerlist, "config.kafka.brokerlist", DATA_TYPE.OBJECT);
    checkIfExists(config.kafka.isReadFromBeginning, "config.kafka.isReadFromBeginning", DATA_TYPE.BOOLEAN);
    checkIfExists(config.kafka.maxBytesPerPartition, "config.kafka.maxBytesPerPartition", DATA_TYPE.NUMBER);
    checkIfExists(config.kafka.logLevel, "config.kafka.logLevel", DATA_TYPE.NUMBER);

    checkIfExists(config.sse, "config.sse", DATA_TYPE.OBJECT);
    checkIfExists(config.sse.endpoint, "config.sse.endpoint", DATA_TYPE.STRING);
    checkIfExists(config.sse.port, "config.sse.port", DATA_TYPE.NUMBER);
    checkIfExists(config.sse.events, "config.sse.events", DATA_TYPE.OBJECT);
    checkIfExists(config.sse.events.asm, "config.sse.events.asm", DATA_TYPE.OBJECT);
    checkIfExists(config.sse.events.alert, "config.sse.events.alert", DATA_TYPE.OBJECT);

    Object.keys(config.sse.events).forEach(key => { 
        checkIfExists(config.sse.events[key], `config.sse.events.alert.${key}`, DATA_TYPE.OBJECT);
        checkIfExists(config.sse.events[key].enabled, `config.sse.events.alert.${key}.enabled`, DATA_TYPE.BOOLEAN);
        checkIfExists(config.sse.events[key].mapping, `config.sse.events.alert.${key}.mapping`, DATA_TYPE.OBJECT);

        for(var i=0; i < config.sse.events[key].mapping.length; i++){
            checkIfExists(config.sse.events[key].mapping[i].topicName, `config.sse.events.alert.${key}.mapping[${i}].topicName`, DATA_TYPE.STRING);
            checkIfExists(config.sse.events[key].mapping[i].clientId, `config.sse.events.alert.${key}.mapping[${i}].clientId`, DATA_TYPE.STRING);
            checkIfExists(config.sse.events[key].mapping[i].groupId, `config.sse.events.alert.${key}.mapping[${i}].groupId`, DATA_TYPE.STRING);
        }
    });
};

/**
 * self running module to initialise all the variables with required data.
 */
(() => {
    logger.info("Validating configuration parameters.");
    validateConfigfileParameters();
    logger.info("Validated configuration parameters successfully.");
})();

module.exports = {
    isSamePlugID,
    handleAsmRequest,
    handlerAlertRequest,
    handlerDeviceRequest,
    handlerProcessRequest,
    getEmitter,
    bunyan,
    EVENTS_CONSTANTS
}
