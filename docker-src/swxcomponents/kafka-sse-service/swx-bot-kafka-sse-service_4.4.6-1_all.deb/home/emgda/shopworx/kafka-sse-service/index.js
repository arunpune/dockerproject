const utility = require('./src/utils/utility.js');
const config = require('./config/config.json');
const express = require('express');
const server = express();
const events = config.sse.events;
const eventNames = Object.keys(events);
const bunyan = utility.bunyan;
/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'index',
    level: config.logLevel
});

/**
 * Register event listener.
 * 
 * @param {string} eventName 
 */
const registerEventListener = (eventName) => {
    let route = '';
    switch (eventName) {        
        case utility.EVENTS_CONSTANTS.ASM:
            route = `/${config.sse.endpoint}/${eventName}/`;
            logger.error(`Setting route: ${route}`);
            server.get(route, utility.handleAsmRequest);
            break;
        case utility.EVENTS_CONSTANTS.ALERT:
            route = `/${config.sse.endpoint}/${eventName}/`;
            logger.error(`Setting route: ${route}`);
            server.get(route, utility.handlerAlertRequest);
            break;
        case utility.EVENTS_CONSTANTS.DEVICE:
            route = `/${config.sse.endpoint}/${eventName}/`;
            logger.error(`Setting route: ${route}`);
            server.get(route, utility.handlerDeviceRequest);
            break;
        case utility.EVENTS_CONSTANTS.PROCESS:
            route = `/${config.sse.endpoint}/${eventName}/`;
            logger.error(`Setting route: ${route}`);
            server.get(route, utility.handlerProcessRequest);
            break;
        default:
            logger.fatal('No relevant event configured.');
            process.exit(1);
    }
}

// Loop all events and create consumer objects
logger.error(`Total events Identified: ${eventNames.length}`);

/**
 * loop into the name of eventNames and then create kafka consumers as configured.
 */
eventNames.forEach(async (eventName) => {
    const eventObj = config.sse.events[eventName];
    if (eventObj.enabled) {
        logger.error(`Initiating consumer for event: ${eventName}`);
        const mappings = eventObj.mapping;
        const Consumer = require('./src/main/consumer.js');
        mappings.forEach(async (mapping, index) => {
            logger.error(`Consumer: ${index + 1} | event: ${eventName}`);
            const consumerObject = new Consumer(config.kafka.brokerlist, mapping.clientId,
                mapping.groupId, mapping.topicName, config.kafka.isReadFromBeginning,
                config.kafka.maxBytesPerPartition, config.kafka.logLevel, eventName);
            await consumerObject
                .start()
                .catch(error => { logger.error(error) });
        });
        registerEventListener(eventName);
    } else {
        logger.fatal(`Event: ${eventName} is disabled.`)
    }
});

server.listen(config.sse.port, () => {
    logger.error(`SSEvent app is now up and running on port ${config.sse.port}!`);
});

