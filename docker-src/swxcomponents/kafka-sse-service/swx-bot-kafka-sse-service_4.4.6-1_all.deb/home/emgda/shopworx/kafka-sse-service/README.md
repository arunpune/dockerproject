# Kafka-SSE Service

**README** (Best readable when this page content copied on left side of the website [https://dillinger.io/](https://dillinger.io/)) #

 Introduction
 ------------
 
1. If an architecture demands data from multiple Kafka topics to be send on a paricular endpoint through SSE then this package has the capability to do it.
2. One can clone this repository and start an extension of capabilities on top of this service.
3. User can map N number of topics to a http endpoint for SSevent and then all the data from these topics will be published on this end point.

 
configuration parameters description
 -------------------
| configuration parameter  | Description  | Default value | Examples |
| :---------------------- |:-------------| :-------| :-------|
| `server.hostname` | the host for SWX Server. | `host` | any [number] relevant hostname or IP.
| `server.port` | the port for Swx Server. | `1061` | any [number] relevant port.
| `kafka.brokerlist` | list of clustered Kafka brokers. it comprises of array of `<IP_ADDRESS>:<port>` | ["localhost:9092"] | ["localhost:9092", "localhost:9093", "localhost:9094"]
| `kafka.isReadFromBeginning` | Whether to read the topic from beginning. Currently this will not work as by default we have allowed consumer to auto-commit messages | false | true, false
| `kafka.maxBytesPerPartition` | A number in bytes to restrict the intake of messages at partition level. Every partition of a topic is assigned this size. | 1048576 | Any non-negative and valid integer value. 
| `kafka.logLevel` | Kafka Log level | 1 | 0 = NOTHING, 1 = ERROR , 2 = WARN, 4 = INFO, 5 = DEBUG
| `sse.endpoint` | endpoint where user must hit. Consider example, http://localhost:3000/sse/{:PlugId}. Do not change this unless required. | `sse` | `sse`
| `sse.port` | port where server msut start. Consider example, http://localhost:3000/sse/{:PlugId}. Do not change this unless required. | 3000 | Any valid port number.
| `sse.events.X`      | Any route that will cater the request with Kakfa topic data. Ensure `asm` and `alert` is mandatory. If these are not provided then error shall be thrown and application will exit.  | `asm` and `alert`  | currently only `asm`, `alert` allowed.
| `sse.events.X.enabled`      | A boolean whether this route is enabled on this server | true  | any boolean like `true` or `false`
| `sse.events.X.mapping.$.topicName` | Name of the topic  | "transformationfacts"  | any valid and meaning name.
| `sse.events.X.mapping.$.clientId` | clientId for the topic that belongs to a certain group | `microservicename-1` | any meaning and unique clientId. Kindly make sure that this does not clash with any other client Id in SWX deployment environment.
| `sse.events.X.mapping.$.groupId`  | groupId for the consumer | `microservicename-group` |  any meaningful and unique groupId in SWX deployment environment.

Pre-requisites
 ------------
 1. Please make sure that `node version 12.16.1` OR above stable release is installed.
 2. Please make sure you fill appropriate configurations in `config/config.json` file.
 3. Please ensure that this connector is tested with SWX-Platform 4.1.x latest release build version.

Installation in DEV
 ------------
 checkout the project and go into the project main directory and run command below sequentially.
 1. `npm install` [**Note**: Use this command only once.]
 2. `node index.js`

Deployment in DEV
 ------------
 Install the debian with usual procedure.

Who do I talk to?
----------------
**Product** - Ankur Soni **<asoni@entrib.com>**
**Product peer** - Ankit Jain **<ajain@entrib.com>**
**Manager** - Kiran Nataraj **<kiran@entrib.com>**