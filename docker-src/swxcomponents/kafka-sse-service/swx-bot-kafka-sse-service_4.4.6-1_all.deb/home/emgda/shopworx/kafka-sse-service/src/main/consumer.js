const { Kafka, CompressionTypes } = require('kafkajs');
const utility = require('../utils/utility.js');
const config = require('../../config/config.json');
const bunyan = utility.bunyan;

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'consumer',
    level: config.logLevel
});

/**
 * Consumer Implementation.
 */
class Consumer {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, 
                    maxBytesPerPartition, kafkaLogLevel, eventName) {
        this.brokerList = brokerList;
        this.clientId = clientId;
        this.groupId = groupId;
        this.topicName = topicName;
        this.isReadFromBeginning = isReadFromBeginning;
        this.kafkaLogLevel = kafkaLogLevel;
        this.maxBytesPerPartition = maxBytesPerPartition;
        this.eventName = eventName;
        // initialise a consumer to begin consumption operation
        this.initConsumer();
    }

    /**
     * initialise a consumer with basic mandatory parameters.
     */
    initConsumer() {
        const kafka = new Kafka({
            clientId: this.clientId,
            brokers: this.brokerList,
            logLevel: this.kafkaLogLevel
        });
        this.consumer = kafka.consumer({ groupId: this.groupId, maxBytesPerPartition: this.maxBytesPerPartition });
    }

    /**
     * Start a consumer.
     */
    async start() {
        await this.consumer.connect();
        logger.error('Successfully Connected consumer.');
        await this.consumer.subscribe({ topic: this.topicName, fromBeginning: this.isReadFromBeginning });
        logger.error('Successfully subscribed to consumer topic: ' + this.topicName);
        await this.consumer.run({
            eachMessage: async ({ topic, partition, message }) => {
                //---------- Pause listening -----------
                this.consumer.pause();
                //-------------- Logging -----------------
                const partialLog = `Topic: ${topic}, Partition: ${partition}, Offset: ${message.offset}`;
                const msg = message.value.toString();
                logger.error(partialLog);
                logger.trace(`${partialLog}, Value: ${msg}`);
                //-------------- Process -----------------
                this.publishSSEvent(msg);
                //--------- resume listening ----------
                this.consumer.resume();
            }
        });
    }

    /**
     * Publish a message over a topic via a producer in producer.
     * 
     * @param {string} message 
     */
    publishSSEvent(message) {
        // do processing [like delegating message to promise].
        logger.trace(`PUBLISH MESSAGE | topic: ${this.topicName} | eventName : ${this.eventName}`);
        utility.getEmitter().emit(this.eventName, message);
    }
}

module.exports = Consumer;