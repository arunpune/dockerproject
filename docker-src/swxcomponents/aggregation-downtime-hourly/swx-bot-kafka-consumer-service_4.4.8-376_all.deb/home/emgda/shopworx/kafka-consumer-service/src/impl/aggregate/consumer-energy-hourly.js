const config = require('../../../config/config.json');
const Aggregation = require('../../base/aggregation.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const HTTP_SUCCESS_CODE = 200;
/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'consumer-energy-hourly',
    level: config.logLevel
});

/**
 * Aggregation Implementation.
 */
class ConsumerEnergyHourly extends Aggregation {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
        this.collectionName = 'aggregatehourly';
        this.type = 'hourly';
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     * 
     */
    async initDB() {
        await super.initDB();
        logger.error('Consumer to Energy hourly aggregation service flow initialised.');
        return 0;
    }

    /**
     * Populate all asset related data by calling an API and storing them in memory.
     */
    async initAssets() {
        // call API 
        const credentials = config.client.credentials;
        let response = await utility.getAuth(credentials, { 'loginType': 'ORIGIN' });
        if (!response || !response.status || HTTP_SUCCESS_CODE !== response.status) {
            logger.error(`Error in authentication to server ${JSON.stringify(response.data)}`);
            this.retryInitAsset();
        }
        logger.trace('Successfully authenticate to server.');
        response = await utility.getAsset({ 'sessionId': response.data.sessionId });
        if (!response || !response.status || HTTP_SUCCESS_CODE !== response.status || !response.data.results) {
            logger.error(`Error while getting assets ${JSON.stringify(response.data)}`);
            this.retryInitAsset();
        }
        logger.trace('Settings Assets.');
        utility.setAssets(response.data.results);
    }

    async retryInitAsset() {
        await utility.sleep(5000);
        await this.initAssets();
        return;
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        try {
            const jsonObj = JSON.parse(message);
            if (!this.isValid(jsonObj)) {
                logger.trace('Skipping as data did not pass validation.');
                return;
            }
            const collection = this.db.collection(this.collectionName);
            return new Promise((resolve, reject) => { 
                collection.findOneAndUpdate(this.getCondition(jsonObj), this.getOperator(jsonObj), { "upsert": true, returnOriginal: false }, (err, document) => {
                    if (err) {
                        logger.fatal("Error occured while upsert to aggregation collection : " + JSON.stringify(err));
                    } else if (!document || (Object.keys(document).length === 0 && document.constructor === Object)) {
                        logger.error('Seems like the record is not getting updated. Kindly check Collection.');
                    } else if (document.value === null) {
                        // In upsert, if record is created then document returned is null.
                        logger.error('Seems like the record is inserted at Backend.');
                    } else {
                        logger.error(`document saved successfully!!`, jsonObj.metername);
                        document.value.type = this.type;
                        const str = JSON.stringify(document.value);
                        super.publish(str);
                        //super.publishAggreationFacts(str);
                    }
                    resolve();
                });
            });
        } catch (error) {
            logger.error("Error while processing." + error + JSON.stringify(error));
            return;
        }
    }
  
    isValid(jsonObj) {
        const obj = utility.getAssets().find(o => o.id === jsonObj.assetid);
        if (!obj) {
            logger.error("No relevant object identified while checking asset.");
            return false;
        }
        const assetName = obj.assetName;
        // check for Energy Meter
        if ('energymeter' === assetName) {
            return true;
        }
        return false;
    }

    /**
     * Get Query Condition for mongodb.
     * 
     * @param {object} jsonObj 
     */
    getCondition(jsonObj) {
        return  this.storeCondition(jsonObj);
    }

    /**
     * Get operator to work on update query for mongodb.
     * 
     * @param {object} jsonObj 
     */
    getOperator(jsonObj) {
        const lastUpdatedAt = new Date();
        let value = {
            "$inc": {
                "kwh_sum": jsonObj.differenceinkwh,
                "kvah_sum": jsonObj.differenceinkvah,
                "watts_sum": jsonObj.watts,
                "pf_sum": jsonObj.pf,
                "vll_sum": jsonObj.vll,
                "vln_sum": jsonObj.vln,
                "current_sum": jsonObj.current,
                "frequency_sum": jsonObj.frequency, 
                "count": 1
            },
            "$max": {
                "watts_max": jsonObj.watts,
                "pf_max": jsonObj.pf,
                "vll_max": jsonObj.vll,
                "vln_max": jsonObj.vln,
                "current_max": jsonObj.current,
                "frequency_max": jsonObj.frequency           
            },
            "$min": {
                "watts_min": jsonObj.watts,
                "pf_min": jsonObj.pf,
                "vll_min": jsonObj.vll,
                "vln_min": jsonObj.vln,
                "current_min": jsonObj.current,
                "frequency_min": jsonObj.frequency
            },
            $set: {
                "updatedAt": lastUpdatedAt,
                "kwh": jsonObj.meterkwh,
                "kvah": jsonObj.meterkvah,
                "watts": jsonObj.watts,
                "pf": jsonObj.pf,
                "vll": jsonObj.vll,
                "vln": jsonObj.vln,
                "current": jsonObj.current,
                "frequency": jsonObj.frequency,
                "meterstatus": jsonObj.meterstatus || 0,
                "date": jsonObj.date,
                "shift": jsonObj.shiftName,
                "displayHour": jsonObj.displayHour,
                "updatedAtTimestamp": lastUpdatedAt.getTime()
            }
        }
        logger.trace("OPERATOR: " + JSON.stringify(value));
        return value;
    }

    /**
     * Store condition and return the same object.
     * 
     */
    storeCondition(jsonObj) {
        const value = {
            "customerId": jsonObj.customerId,
            "siteId": jsonObj.siteId,
            "elementName": jsonObj.elementName,
            "metername": jsonObj.metername,
            "metergroup": jsonObj.metergroup,
            "metersubgroup": jsonObj.metersubgroup,
            "metersubsubgroup": jsonObj.metersubsubgroup,
            "year": jsonObj.year,
            "month": jsonObj.month,
            "day": jsonObj.day,
            "hour": jsonObj.hour,
            "week": jsonObj.week
        }
        return value;
    }
}

module.exports = ConsumerEnergyHourly;