const { Kafka, CompressionTypes } = require('kafkajs');
const utility = require('../utils/utility.js');
const config = require('../../config/config.json');
const bunyan = utility.bunyan;
/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'consumer',
    level: config.logLevel
});

/**
 * Consumer Implementation.
 */
class Consumer {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel) {
        this.brokerList = brokerList;
        this.clientId = clientId;
        this.groupId = groupId;
        this.topicName = topicName;
        this.isReadFromBeginning = isReadFromBeginning;
        this.kafkaLogLevel = kafkaLogLevel;
        this.maxBytesPerPartition = maxBytesPerPartition;
        // initialise a consumer to begin consumption operation
        this.initConsumer();
        if (config.isProducerEnabled) {
            this.producerTopic = config.producer.topicName;
            // initialise a producer to begin production operation over a topic.
            this.initProducer();
        }
    }

    /**
     * initialise a consumer with basic mandatory parameters.
     */
    initConsumer() {
        const kafka = new Kafka({
            clientId: this.clientId,
            brokers: this.brokerList,
            logLevel: this.kafkaLogLevel
        });
        this.consumer = kafka.consumer({ groupId: this.groupId, maxBytesPerPartition: this.maxBytesPerPartition });
    }

    /**
     * initialise a producer with basic mandatory parameters.
     */
    async initProducer() {
        const kafka = new Kafka({
            clientId: this.clientId,
            brokers: this.brokerList,
            logLevel: this.kafkaLogLevel
        });
        this.producer = kafka.producer();
        await this.producer.connect();
    }

    /**
     * Start a consumer.
     */
    async start() {
        await this.consumer.connect();
        logger.error('Successfully Connected consumer.');
        await this.consumer.subscribe({ topic: this.topicName, fromBeginning: this.isReadFromBeginning });
        logger.error('Successfully subscribed to consumer topic: ' + this.topicName);
        if (config.consumer.isBatchEnabled) {
            await this.consumer.run({
                eachBatchAutoResolve: false,
                eachBatch: async ({ batch, resolveOffset, heartbeat, isRunning, isStale }) => {
                    //---------- Pause listening -----------
                    this.consumer.pause();
                    for (let message of batch.messages) {
                        if (!isRunning() || isStale()) break;
                        //-------------- Logging -----------------
                        const partialLog = `Topic: ${batch.topic}, Partition: ${batch.partition}, Offset: ${message.offset}`;
                        const msg = message.value.toString();
                        logger.error(partialLog);
                        logger.trace(`${partialLog}, Value: ${msg}`);
                        //-------------- Process -----------------
                        await this.process(msg);
                        // this.publishSSEvent(msg);

                        //----------- resolve offset -------------
                        resolveOffset(message.offset);
                        //-------------- hearbeat ----------------
                        await heartbeat();
                    }
                    //--------- resume listening ----------
                    this.consumer.resume();
                },
            });
        } else {
            await this.consumer.run({
                eachMessage: async ({ topic, partition, message }) => {
                    //---------- Pause listening -----------
                    this.consumer.pause();
                    //-------------- Logging -----------------
                    const partialLog = `Topic: ${topic}, Partition: ${partition}, Offset: ${message.offset}`;
                    const msg = message.value.toString();
                    logger.error(partialLog);
                    logger.trace(`${partialLog}, Value: ${msg}`);
                    //-------------- Process -----------------
                    await this.process(msg);
                    // this.publishSSEvent(msg);

                    //--------- resume listening ----------
                    this.consumer.resume();
                }
            });
        }
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        // Do processing [like delegating message to promise].
        // publish message over a topic via producer.
        if (config.isProducerEnabled) {
            this.publish(message);
        } else {
            // Some other process format.
        }
    }

    /**
     * Publish a message over a topic via a producer in producer.
     * 
     * @param {string} message 
     */
    async publish(message, dynamicTopic) {
        // do processing [like delegating message to promise].
        let publishtopic = this.producerTopic;
        if(dynamicTopic) {
            publishtopic = dynamicTopic;
        }
        const payload = { topic: publishtopic, compression: CompressionTypes.None, messages: [{ key: null, value: message }] };
        logger.error("Published Message.");
        logger.trace("Published Message: " + JSON.stringify(payload));
        this.producer
            .send(payload)
            .catch(error => { logger.error(error) });
    }

    /**
     * Publish a message over a topic via a producer in producer.
     * 
     * @param {string} message 
     */
    async publishAggreationFacts(message) {
        // do processing [like delegating message to promise].
        const payload = { topic: 'aggregation-facts', compression: CompressionTypes.None, messages: [{ key: null, value: message }] };
        logger.error("Published aggregation facts message.");
        this.producer
            .send(payload)
            .catch(error => { logger.error(error) });
    }

    publishSSEvent(message) {
        utility.getEmitter().emit("alarm", message);
    }
}

module.exports = Consumer;