const config = require('../../../config/config.json');
const configRule = require('../../../config/rule.json');
const messagetemplates = require('../../../config/template.json');

const Alert = require('../../base/alert.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const { Engine } = require("json-rules-engine");
const engine = new Engine();

const logger = bunyan.createLogger({
    name: 'alert-process',
    level: config.logLevel
});

const { pushnotification, emailnotification } = messagetemplates.templates;

class AlertProcess extends Alert {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
    */

    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
        this.collectionName = 'process';
        // this.elementName = 'latestprocess';
    }

    async initDB() {
        try {
            await super.initDB();
            logger.error('Alert to get latest process service flow initialised.');
            return 0;
        } catch (error) {
            logger.error("Error while connecting database. " + error + JSON.stringify(error));
            return;
        }
    }

    initRuleEngine() {
        try {
            configRule.rules.map((rule) => {
                let ruleobject = {};
                ruleobject.conditions = rule.ruleCondition;
                ruleobject.event = {
                    type: rule.type,
                    params: {
                        ruleid: rule.id,
                        name: rule.name,
                        notification: rule.notification,
                        type: rule.type,
                        priority: rule.priority
                    }
                };
                engine.addRule(ruleobject);
            })
        } catch (error) {
            logger.error("Invalid rules, please check rules configuration. " + error + JSON.stringify(error));
            return;
        }
    }

    async initAssets() {
        try {
            this.initRuleEngine();
        } catch (error) {
            logger.error("Error while initializing assets. " + error + JSON.stringify(error));
            return;
        }
    }

    async process(message) {
        try {
            message = JSON.parse(message);
            if (message.customerId && message.siteId && message.lineid && message.sublineid && message.stationid && message.substationid && message.parametername) {
                this.ruleEngine(message);
            }
        } catch (error) {
            logger.error("Error while processing kafka message. " + error + JSON.stringify(error));
            return;
        }
    }

    async ruleEngine(message) {
        try {

            return await engine.run(message).then((response) => {

                if (response.almanac.events.success.length) {
                    response.almanac.events.success.map((res, i) => {
                        let result;
                        if (response.results[i]["conditions"]["all"]) {
                            result = response.results[i]["conditions"]["all"];
                        } else if (response.results[i]["conditions"]["any"]) {
                            result = response.results[i]["conditions"]["any"];
                        }
                        this.updateSuccessDocument(message, res, result)
                    })
                }
                if (response.almanac.events.failure.length) {
                    response.almanac.events.failure.map((res) => {
                        this.updateFailDocument(message, res);
                    })
                }
            }, (error) => {
                logger.error("error ", error);
            });

        } catch (error) {
            logger.error("Error while processing rule engine. " + error + JSON.stringify(error));
            return;
        }
    }

    updateSuccessDocument(message, event, result) {
        try {
            let collectionName = 'alarm';
            const collection = this.db.collection(collectionName);
            let query = {
                "key": message.customerId + "_" + message.siteId + "_" + message.lineid + "_" + message.sublineid + "_" + message.stationid + "_" + message.substationid + "_" + event.params.ruleid + "_" + message.parametername + "_on"
            }

            let operator;
            let threshold;
            let actualvalue;
            let onTime = new Date();

            if (result.length) {
                result.map((res, i) => {
                    if (res.fact === "value") {
                        operator = res.operator;
                        threshold = res.value;
                        actualvalue = res.factResult;
                    }
                })
            }

            message.actualvalue = actualvalue;
            message.onTime = onTime;
            message.threshold = threshold;

            let options = { upsert: true, returnOriginal: false };

            if (operator === "greaterThan" || operator === "greaterThanInclusive") {
                message.operator = "has been exceeded than";

            } else if (operator === "lessThan" || operator === "lessThanInclusive") {
                message.operator = "has been lesser than";

            } else {
                message.operator = "equals";
            }

            let processmessage = '';

            event.params.notification.map((mechanism) => {
                if (mechanism.deliveryMechanism == "PUSH") {
                    processmessage = utility.fillTemplate(pushnotification.processtemplates.parameter, message);
                    mechanism.template = processmessage;
                } else if (mechanism.deliveryMechanism == "EMAIL") {
                    processmessage = emailnotification.processtemplates.parameter;
                    processmessage.body = utility.fillTemplate(processmessage.body, message);
                    processmessage.subject = utility.fillTemplate(processmessage.subject, message);
                    mechanism.template = processmessage;
                } else if (mechanism.deliveryMechanism == "SMS") {
                    processmessage = utility.fillTemplate(pushnotification.processtemplates.parameter, message);
                    mechanism.template = processmessage;
                }
            })
            let update = {
                $set: {
                    "type": event.params.type,
                    "ruleCondition": result,
                    "meta": {
                        "substationid": message.substationid,
                        "parametername": message.parametername
                    },
                    "ruleid": event.params.ruleid,
                    "name": event.params.name,
                    "offTime": "",
                    "priority": event.params.priority,
                    "customerId": message.customerId,
                    "siteId": message.siteId,
                    "status": "inProgress",
                    "notification": event.params.notification,
                },
                $setOnInsert: {
                    "onTime": onTime
                }
            }

            return new Promise((resolve, reject) => {
                collection.findOneAndUpdate(query, update, options, (err, document) => {
                    if (err) {
                        logger.fatal("Error occured while upsert to aggregation collection : " + JSON.stringify(err));
                    } else if (!document || (Object.keys(document).length === 0 && document.constructor === Object)) {
                        logger.error('Seems like the record is not getting updated. Kindly check Collection.');
                    } else if (document.value === null) {
                        logger.error('Seems like the record is inserted at Backend.');
                    }
                    else {
                        if (document.lastErrorObject["updatedExisting"] === false) {
                            logger.error(`Alert! Rule id "${document.value.ruleid}" for rule name "${document.value.name}" exceeded!`);

                            logger.error("Successfully inserted or updated document.");
                            if (document.value) {
                                document.value.notification.map((mechanism) => {
                                    let obj = {
                                        meta: document.value.meta,
                                        type: document.value.type,
                                        notification: mechanism
                                    };
                                    obj = JSON.stringify(obj);

                                    super.publish(obj, utility.NOTIFICAITON_TOPICS[mechanism.deliveryMechanism]);
                                    // if (mechanism.deliveryMechanism === "PUSH") {
                                    //     let obj = {
                                    //         meta: document.value.meta,
                                    //         type: document.value.type,
                                    //         notification: mechanism
                                    //     };

                                    //     obj = JSON.stringify(obj);
                                    //     super.publish(obj, TOPICS[mechanism.deliveryMechanism]);
                                    // } else if (mechanism.deliveryMechanism === "EMAIL") {
                                    //     let obj = {
                                    //         meta: document.value.meta,
                                    //         type: document.value.type,
                                    //         notification: mechanism
                                    //     };
                                    //     obj = JSON.stringify(obj);
                                    //     super.publish(obj, TOPICS[mechanism.deliveryMechanism]);
                                    // } else if (mechanism.deliveryMechanism === "SMS") {
                                    //     let obj = {
                                    //         meta: document.value.meta,
                                    //         type: document.value.type,
                                    //         notification: mechanism
                                    //     };
                                    //     obj = JSON.stringify(obj);
                                    //     super.publish(obj, TOPICS[mechanism.deliveryMechanism]);
                                    // }
                                })
                            }
                        } else {
                            logger.error(`Same Alert! Rule id "${document.value.ruleid}" for rule name "${document.value.name}" exceeded again!`)
                        }
                    }
                    resolve();
                });
            });
        } catch (error) {
            logger.error("Error while saving in progress alarm. " + error + JSON.stringify(error));
            return;
        }

    }

    updateFailDocument(message, event) {
        try {
            let collectionName = 'alarm';
            const collection = this.db.collection(collectionName);

            let query = {
                key: message.customerId + "_" + message.siteId + "_" + message.lineid + "_" + message.sublineid + "_" + message.stationid + "_" + message.substationid + "_" + event.params.ruleid + "_" + message.parametername + "_on",
            }

            let update = {
                "$set": {
                    "key": message.customerId + "_" + message.siteId + "_" + message.lineid + "_" + message.sublineid + "_" + message.stationid + "_" + message.substationid + "_" + event.params.ruleid + "_" + message.parametername + "_off",
                    "status": "complete",
                    "offTime": new Date().getTime(),
                }
            }
            const options = { returnNewDocument: true };

            return collection.findOneAndUpdate(query, update, options)
                .then((updatedDocument) => {
                    if (updatedDocument.value) {
                        logger.error(`Process parametername ${message.parametername} does not exceeded.`);
                    } else {
                        logger.error("Alert rule conditions does not met");
                        logger.error("No document matches the provided query.");

                    }
                })
                .catch((err) => logger.error(`Failed to find and update document: ${err}`));
        } catch (error) {
            logger.error("Error while saving complete alarm. " + error + JSON.stringify(error));
            return;
        }


    }
}

module.exports = AlertProcess;
