const config = require('../../../config/config.json');
const Transformation = require('../../base/transformation.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const { CompressionTypes } = require('kafkajs');

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'asset-state-shift',
    level: config.logLevel
});

/**
 * Aggregation Implementation.
 */
class TransformAssetStateShift extends Transformation {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
        this.transformationAssetStateShift = 'transformation-facts';
        this.type = "shift";
        this.aggregateCollection = "aggregateshift";
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     */
    async initDB() {
        await super.initDB();
        logger.error('Transformation Asset State Shiftwise service flow initialised.');
        return 0;
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        let obj = {};
        try {
            obj = JSON.parse(message);
        } catch (error) {
            logger.error("Could not parse string to JSON object while processing." + error + JSON.stringify(error));
            return;
        }
        const data = obj.value || obj;
        logger.trace('Transformation Asset State Shiftwise service received data: ' + JSON.stringify(data));
        if (!data) {
            return;
        }
        /**
         * Get Process Parameter if any
         */
        const pd = await this.getProcessData(this.aggregateCollection, this.getProcessDataCondition(data));
        const processData = pd.obj || {};
        /**
         * GET PERFORMANCE AND AVAILABILITY
         */
        const performance = await this.getPerformance(this.aggregateCollection, this.getPerfCondition(data));
        if (0 === Object.keys(performance)) {
            logger.info("No Performance/ Availability found.");
            return;
        }
        /**
         * GET QUALITY
         */
        const qualityObj = await this.getQuality(this.aggregateCollection, performance.qty, this.getQualityCondition(data));
        performance.quality = qualityObj.quality;
        performance.rqty = qualityObj.rqty;
        /**
         * GET OEE
         */
        logger.info("Calculating OEE.");
        const OEE = super.getOEE(performance.availability, performance.performance, performance.quality);
        const assetStateObj =  {...data, ...performance, ...processData};
        // adding more more keys
        assetStateObj.oee = OEE;
        assetStateObj.type = this.type;
        logger.info(`KEY: ${utility.buildConditionKey(data)}, APQ: [${assetStateObj.availability}, `+
                        `${assetStateObj.performance}, ${assetStateObj.quality}], OEE: ${OEE}`);
        const objStr = JSON.stringify(assetStateObj);
        this.publishMachineOEE(objStr);
        const originalData = {...assetStateObj, ...data};
        this.publishOEE(JSON.stringify(originalData));
    }

    /**
     * Get ProcessData.
     * 
     * @async
     * @param {object} aggregateCollection 
     * @param {object} condition 
     */
    async getProcessData(aggregateCollection, condition) {
        const collection = this.db.collection(aggregateCollection);
        // run DB query using promise, resolve the value, on exception log the error, but return -1
        return new Promise((resolve, reject) => {
            logger.trace("getProcessData condition: " + JSON.stringify(condition));
            collection.findOne(condition, (err, document) => {
                logger.trace("Document identified while searching process data aggregation: " + JSON.stringify(document));
                if (err) {
                    logger.fatal("Error occured while finding process data record in aggregation collection : " + JSON.stringify(err));
                    resolve({ "obj": document });
                } else if (null === document) {
                    // this means that no process data aggregation record was found, so processData has to be 100% during that hour bracket.
                    logger.error("process data record not found in aggregation collection.");
                    resolve({ "obj": document });
                } else {
                    resolve({ "obj": document });
                }
            });
        });
    }

    /**
     * Get Performance and Availability.
     * 
     * @async
     * @param {object} jsonObj
     */
    async getPerformance(aggregateCollection, condition) {
        const collection = this.db.collection(aggregateCollection);
        // run DB query using promise, resolve the value, on exception log the error, but return -1
        let docs;
        try {
            docs = await collection.find(condition).toArray();
            logger.trace(`${docs.length} document found for production aggregation. ${(docs.length ? '' : 'Skipping.')}`);
        } catch (error) {
            logger.error("Error finding production record in aggregation collection : " + JSON.stringify(err));
            return {};
        }
        if(!docs || !docs.length) return {};
        const groupByPlanID = utility.groupBy(docs, 'planid');
        return this.getPerfandAvail(groupByPlanID, docs);
    }

    getPerfandAvail(groupByPlanID, docs) {
        const planIDs = Object.keys(groupByPlanID);
        let final = [];
        planIDs.forEach((planid)=> {
            let planArr = groupByPlanID[planid];
            const { trial } = planArr[0];
            const partnames = [...new Set(planArr.map((obj)=>obj.partname))];
            const ar = [];
            partnames.forEach((partname) => {
                const arr = planArr.reduce((acc, curr) => { if(curr.partname === partname) { acc.push(curr); } return acc;}, []);
                const actm_sum = Math.floor(arr.reduce((acc, curr) => acc += curr.actm_sum , 0));
                const qty = Math.floor(arr.reduce((acc, curr) => acc += curr.qty , 0));
                const targetQty = Math.floor(arr.reduce((acc, curr) => acc += curr.targetQty , 0));
                ar.push({actm_sum, qty, targetQty});
            });
            const actm_sum = Math.floor(ar.reduce((acc, curr) => acc += curr.actm_sum , 0) / ar.length);
            const qty = Math.floor(ar.reduce((acc, curr) => acc += curr.qty , 0));
            const targetQty = Math.floor(ar.reduce((acc, curr) => acc += curr.targetQty , 0));
            final.push({actm_sum, qty, targetQty, planid, trial});   
        });
        const trial_duration = Math.floor(final.reduce((acc, curr) => {
            if (curr.trial) {
                acc += curr.actm_sum;
            }
            return acc;
        }, 0));
        const actm_sum = Math.floor(final.reduce((acc, curr) => {
            if (!curr.trial) {
                acc += curr.actm_sum;
            }
            return acc;
        }, 0));
        const qty = Math.floor(final.reduce((acc, curr) => {
            if (!curr.trial) {
                acc += curr.qty;
            }
            return acc;
        }, 0));
        const targetQty = Math.floor(final.reduce((acc, curr) => {
            if (!curr.trial) {
                acc += curr.targetQty;
            }
            return acc;
        }, 0));
        const result = {actm_sum, qty, targetQty};
        const availableTime = docs[0].shiftAvailableTime - trial_duration;
        result.targetQty = targetQty;
        result.performance = utility.roundOff((qty / targetQty) * 100);
        result.availability = utility.roundOff(( actm_sum / availableTime) * 100);
        result.runtime = actm_sum;
        result.trialduration = trial_duration;
        result.availabletime = availableTime;
        return result;
    }

    /**
     * Get Quality.
     * 
     * @async
     * @param {object} jsonObj
     */
    async getQuality(aggregateCollection, actualQuantity, condition) {
        const collection = this.db.collection('rejection');
        // run DB query using promise, resolve the value, on exception log the error, but return -1
        let docs;
        try {
            docs = await collection.find(condition).toArray();
            logger.error(`${docs.length} document found for rejection aggregation. ${(docs.length ? '' : 'Skipping.')}`);
        } catch (error) {
            logger.error("Error finding rejection record in aggregation collection : " + JSON.stringify(err));
            return { quality: 100, rqty: 0 };
        }
        // No rejection record means that Quality = 100;
        if(!docs || !docs.length) return { quality: 100, rqty: 0 };
        const rqty = Math.floor(docs.reduce((acc, curr) => acc += curr.quantity , 0));
        const quality = utility.roundOff(((actualQuantity - rqty) / actualQuantity) * 100);
        logger.trace(`ActualQty:${actualQuantity}, RejectQty: ${rqty}, Quality: ${quality}`);
        return { quality, rqty };
    }

    /**
     * Get process data condition.
     * 
     * @param {object} jsonObj 
     */
    getProcessDataCondition(jsonObj) {
        return this.getCondition(jsonObj, "processparameter");
    }

    /**
     * Get Performance condition.
     * 
     * @param {object} jsonObj 
     */
    getPerfCondition(jsonObj) {
        return this.getCondition(jsonObj, "cycletime");
    }

    /**
     * Get Quality condition.
     * 
     * @param {object} jsonObj 
     */
    getQualityCondition(jsonObj) {
        return this.getCondition(jsonObj, "rejection");
    }

    /**
     * Get Generic condition.
     * 
     * @param {object} jsonObj 
     * @param {String} elementName 
     */
    getCondition(jsonObj, elementName) {
        const data = {
            customerId: jsonObj.customerId,
            siteId: jsonObj.siteId,
            elementName,
            machinename: jsonObj.machinename,
            day: jsonObj.day,
            month: jsonObj.month,
            year: jsonObj.year,
            week: jsonObj.week
        };
        if('cycletime' === elementName) {
            data.shift = jsonObj.shift || jsonObj.shiftName;
        } else {
            data.shiftName = jsonObj.shift || jsonObj.shiftName;
        }
        return data;
    }

    /**
     * Publish message that will also include Performance parameter.
     * 
     * @param {string} message 
     */
    publishOEE(message) {
        // do processing [like delegating message to promise].
        const payload = { topic: this.transformationAssetStateShift, compression: CompressionTypes.None, messages: [{ key: null, value: message }] };
        logger.error("Published Message.");
        logger.info("Published Asset State Shift Message: " + JSON.stringify(payload));
        this.producer
            .send(payload)
            .catch(error => { logger.error(error) });
    }

    publishMachineOEE(message) {
        // do processing [like delegating message to promise].
        const payload = { topic: 'machinewise-oee-shift', compression: CompressionTypes.None, messages: [{ key: null, value: message }] };
        logger.error("Published Machinewise Shiftwise Message");
        this.producer
            .send(payload)
            .catch(error => { logger.error(error) });
    }
}

module.exports = TransformAssetStateShift;