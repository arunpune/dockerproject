const config = require('../../config/config.json');
const Consumer = require('./consumer.js');
const utility = require('../utils/utility.js');
const MongoClient = utility.MongoClient;
const bunyan = utility.bunyan;

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'transformation',
    level: config.logLevel
});
 
/**
 * Consumer Implementation.
 */
class Transformation extends Consumer {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel);
        this.dbDetails = dbDetails;
        this.mongoURL = this.dbDetails.url;
        this.mongoDBName = this.dbDetails.dbName;
        this.dbOptions = this.dbDetails.options;
        this.provisioningCollection = 'provisioning';
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     * 
     */
    async initDB() {
        utility.drawLine();
        logger.error('Initialising DB');
        utility.drawLine();
        let URL = `${this.mongoURL}/${this.mongoDBName}`;
        let client = await MongoClient
            .connect(URL, this.dbOptions)
            .catch((error) => {
                logger.error(`Error while connecting to Mongo URL: ${URL}  : ${error}`);
                utility.drawLine();
            });
        if (!client) {
            process.exit(1);
        }
        // set db object as instance variable for greater performance.
        this.db = client.db(this.mongoDBName);
        logger.error(`Connected to Mongo DB ${URL}`);
        utility.drawLine();
        return true;
    }

    /**
     * Process a message.
     * 
     * @async
     * @param {string} message
     */
    async process(message) { }

    /**
     * Build object.
     * 
     * @param {number} num 
     * @param {object} obj 
     */
    buildObj(num, obj) {
        return {num, obj}
    }

    /**
     * Get Overall Equipment Effectiveness.
     * 
     * @param {number} availability 
     * @param {number} performance 
     * @param {number} quality
     */
    getOEE(availability, performance, quality) { 
        return utility.roundOff(((availability * performance * quality) / 10000));
    }
}

module.exports = Transformation;