const config = require('./config/config.json');
const utility = require('./src/utils/utility.js');
const bunyan = utility.bunyan;
const registry = require('./src/utils/registry.js');
const impl = registry.getRegistry();

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'index',
    level: config.logLevel
});

/**
 * General Consumer base implementation flow.
 */
const generalConsumerFlow = () => {
    const Consumer = require('./src/base/consumer.js');
    // create consumer
    const consumerObject = new Consumer(config.consumer.brokerlist, config.consumer.clientId,
        config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel);
    // start consumer
    consumerObject
        .start()
        .catch(error => { logger.error(error) });
};

/**
 * Consumer for hourly cycletime service flow
 */
const aggregateCycletimeHourlyFlow = () => {
    const ConsumerCycletimeHourly = require('./src/impl/aggregate/consumer-cycletime-hourly.js');
    // create consumer
    const consumerObject = new ConsumerCycletimeHourly(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(async () => {
            await consumerObject.initAssets();
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for hourly cycletime service flow
 */
const aggregateCycletimePlanFlow = () => {
    const ConsumerCycletimePlan = require('./src/impl/aggregate/consumer-cycletime-plan.js');
    // create consumer
    const consumerObject = new ConsumerCycletimePlan(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(async () => {
            await consumerObject.initAssets();
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for Shiftwise cycletime service flow
 */
const aggregateCycletimeShiftFlow = () => {
    const ConsumerCycletimeShift = require('./src/impl/aggregate/consumer-cycletime-shift.js');
    // create consumer
    const consumerObject = new ConsumerCycletimeShift(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(async () => {
            await consumerObject.initAssets();
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for hourly rejection service flow
 */
const aggregateRejectionHourlyFlow = () => {
    const ConsumerRejectionHourly = require('./src/impl/aggregate/consumer-rejection-hourly.js');
    // create consumer
    const consumerObject = new ConsumerRejectionHourly(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start()
        })
        .catch(error => { logger.error(error) });
}

const aggregateRejectionShiftFlow = () => {
    const ConsumerRejectionShift = require('./src/impl/aggregate/consumer-rejection-shift.js');
    // create consumer
    const consumerObject = new ConsumerRejectionShift(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start()
        })
        .catch(error => { logger.error(error) });
}

const aggregateRejectionPlanFlow = () => {
    const ConsumerRejectionPlan = require('./src/impl/aggregate/consumer-rejection-plan.js');
    // create consumer
    const consumerObject = new ConsumerRejectionPlan(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start()
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for hourly downtime service flow
 */
const aggregateDowntimeHourlyFlow = () => {
    const ConsumerDowntimeHourly = require('./src/impl/aggregate/consumer-downtime-hourly.js');
    // create consumer
    const consumerObject = new ConsumerDowntimeHourly(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for hourly downtime service flow
 */
const aggregateDowntimeShiftFlow = () => {
    const ConsumerDowntimeShift = require('./src/impl/aggregate/consumer-downtime-shift.js');
    // create consumer
    const consumerObject = new ConsumerDowntimeShift(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for planwise downtime service flow
 */
const aggregateDowntimePlanFlow = () => {
    const ConsumerDowntimePlan = require('./src/impl/aggregate/consumer-downtime-plan.js');
    // create consumer
    const consumerObject = new ConsumerDowntimePlan(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Transform Cycletime information to A, P, Q, OEE facts.
 */
const transformAssetStateHourlyFlow = () => {
    const TransformAssetStateHourly = require('./src/impl/transform/transform-asset-state-hourly.js');
    // create consumer
    const consumerObject = new TransformAssetStateHourly(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Transform Cycletime information to A, P, Q, OEE facts.
 */
const transformAssetStateShiftFlow = () => {
    const TransformAssetStateShift = require('./src/impl/transform/transform-asset-state-shift.js');
    // create consumer
    const consumerObject = new TransformAssetStateShift(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Transform Cycletime information to A, P, Q, OEE facts.
 */
const transformAssetStatePlanFlow = () => {
    const TransformAssetStatePlan = require('./src/impl/transform/transform-asset-state-plan.js');
    // create consumer
    const consumerObject = new TransformAssetStatePlan(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Persist Machinewise OEE Aggregation data in database.
 */
const machinewiseOEEHourlyFlow = () => {
    const MachinewiseOEEHourly = require('./src/impl/machinefacts/machinewise-oee-hourly');
    // create consumer
    const consumerObject = new MachinewiseOEEHourly(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Persist Machinewise OEE Aggregation data in database.
 */
const machinewiseOEEShiftFlow = () => {
    const MachinewiseOEEShift = require('./src/impl/machinefacts/machinewise-oee-shift.js');
    // create consumer
    const consumerObject = new MachinewiseOEEShift(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(() => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for hourly energy service flow
 */
const aggregateEnergyHourlyFlow = () => {
    const ConsumerEnergyHourly = require('./src/impl/aggregate/consumer-energy-hourly.js');
    // create consumer
    const consumerObject = new ConsumerEnergyHourly(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(async () => {
            await consumerObject.initAssets();
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}
/**
 * Consumer for Shiftwise energy service flow
 */
const aggregateEnergyShiftFlow = () => {
    const ConsumerEnergyShift = require('./src/impl/aggregate/consumer-energy-shift.js');
    // create consumer
    const consumerObject = new ConsumerEnergyShift(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(async () => {
            await consumerObject.initAssets();
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for LatestCycletime Service
 */
const aggregateLatestCycletime = () => {
    const ConsumerLatestCycletime = require('./src/impl/aggregate/consumer-latest-cycletime.js');
    // create consumer
    const consumerObject = new ConsumerLatestCycletime(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(async () => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}


/**
 * Consumer for hourly process service flow
 */
 const aggregateProcessHourlyFlow = () => {
    const ConsumerProcessHourly = require('./src/impl/aggregate/consumer-process-hourly.js');
    // create consumer
    const consumerObject = new ConsumerProcessHourly(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(async () => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

/**
 * Consumer for Shiftwise process service flow
 */
 const aggregateProcessShiftFlow = () => {
    const ConsumerProcessShift = require('./src/impl/aggregate/consumer-process-shift.js');
    // create consumer
    const consumerObject = new ConsumerProcessShift(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    // start consumer
    consumerObject
        .initDB()
        .then(async () => {
            consumerObject.start();
        })
        .catch(error => { logger.error(error) });
}

const alertDowntime = () => {
    const AlertLatestDowntime = require('./src/impl/alert/downtime.js');
    const alertObject = new AlertLatestDowntime(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    //start alert
    alertObject
        .initDB()
        .then(async () => {
            await alertObject.initAssets();
            alertObject.start();
        })
        .catch((error) => { logger.error(error) });
}

const alertProcess = () => {
    const AlertLatestProcess = require('./src/impl/alert/process.js');
    const alertObject = new AlertLatestProcess(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel, config.mongo);
    //start alert
    alertObject
        .initDB()
        .then(async () => {
            await alertObject.initAssets();
            alertObject.start();
        })
        .catch((error) => { logger.error(error) });
}

const notificationSse = () => {
    const NotificationLatestSse = require('./src/impl/notification/sse.js');

    const notificationSseObject = new NotificationLatestSse(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel);
    notificationSseObject.start();
}

const notificationEmail = async () => {
    const NotificationEmail = require('./src/impl/notification/email.js');

    const notificationEmailObject = new NotificationEmail(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel);
    await notificationEmailObject.initAssets();
    notificationEmailObject.start();
}

const notificationSMS = async () => {
    const NotificationSMS = require('./src/impl/notification/sms.js');

    const notificationSMSObject = new NotificationSMS(config.consumer.brokerlist,
        config.consumer.clientId, config.consumer.groupId, config.consumer.topicName,
        config.consumer.isReadFromBeginning, config.consumer.maxBytesPerPartition,
        config.kafkaLogLevel);
    await notificationSMSObject.initAssets();
    notificationSMSObject.start();
    console.log("Inside notification sms");
}


switch (config.instanceType) {
    case impl.CONSUMER:
        generalConsumerFlow();
        break;
    case impl.AGGREGATE_CYCLETIME_HOURLY:
        aggregateCycletimeHourlyFlow();
        break;
    case impl.AGGREGATE_CYCLETIME_SHIFT:
        aggregateCycletimeShiftFlow();
        break;
    case impl.AGGREGATE_CYCLETIME_PLAN:
        aggregateCycletimePlanFlow();
        break;
    case impl.AGGREGATE_REJECTION_HOURLY:
        aggregateRejectionHourlyFlow();
        break;
    case impl.AGGREGATE_REJECTION_SHIFT:
        aggregateRejectionShiftFlow();
        break;
    case impl.AGGREGATE_REJECTION_PLAN:
        aggregateRejectionPlanFlow();
        break;
    case impl.AGGREGATE_DOWNTIME_HOURLY:
        aggregateDowntimeHourlyFlow();
        break;
    case impl.AGGREGATE_DOWNTIME_SHIFT:
        aggregateDowntimeShiftFlow();
        break;
    case impl.AGGREGATE_DOWNTIME_PLAN:
        aggregateDowntimePlanFlow();
        break;
    case impl.TRANSFORM_ASSET_STATE_HOURLY:
        transformAssetStateHourlyFlow();
        break;
    case impl.TRANSFORM_ASSET_STATE_SHIFT:
        transformAssetStateShiftFlow();
        break;
    case impl.TRANSFORM_ASSET_STATE_PLAN:
        transformAssetStatePlanFlow();
        break;
    case impl.MACHINEWISE_OEE_HOURLY:
        machinewiseOEEHourlyFlow();
        break;
    case impl.MACHINEWISE_OEE_SHIFT:
        machinewiseOEEShiftFlow();
        break;
    case impl.AGGREGATE_ENERGY_HOURLY:
        aggregateEnergyHourlyFlow();
        break;
    case impl.AGGREGATE_ENERGY_SHIFT:
        aggregateEnergyShiftFlow();
        break;
    case impl.AGGREGATE_LATEST_CYCLETIME:
        aggregateLatestCycletime();
        break;
    case impl.AGGREGATE_PROCESS_HOURLY: 
        aggregateProcessHourlyFlow();
        break;
    case impl.AGGREGATE_PROCESS_SHIFT: 
        aggregateProcessShiftFlow();
        break;
    case impl.ALERT_PROCESS:
        alertProcess();
        break;
    case impl.ALERT_DOWNTIME:
        alertDowntime();
        break;
    case impl.NOTIFICATION_SSE:
        notificationSse();
        break;
    case impl.NOTIFICATION_EMAIL:
        notificationEmail();
        break;
    case impl.NOTIFICATION_SMS:
        notificationSMS();
        break;
    default:
        logger.fatal('No relevant service Implemented.');
        process.exit(1);
}
