const config = require('../../../config/config.json');
const Aggregation = require('../../base/aggregation.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const HTTP_SUCCESS_CODE = 200;
/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'consumer-process-hourly',
    level: config.logLevel
});

/**
 * Aggregation Implementation.
 */
class ConsumerProcessHourly extends Aggregation {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
        this.collectionName = 'aggregatehourly';
        this.type = 'hourly';
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     * 
     */
    async initDB() {
        await super.initDB();
        logger.error('Consumer to Process hourly aggregation service flow initialised.');
        return 0;
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        try {
            const jsonObj = JSON.parse(message);
            if (!this.isValid(jsonObj)) {
                logger.trace('Skipping as data did not pass validation.');
                return;
            }
            const collection = this.db.collection(this.collectionName);
            return new Promise((resolve, reject) => { 
                collection.findOneAndUpdate(this.getCondition(jsonObj), this.getOperator(jsonObj), { "upsert": true, returnOriginal: false }, (err, document) => {
                    if (err) {
                        logger.fatal("Error occured while upsert to aggregation collection : " + JSON.stringify(err));
                    } else if (!document || (Object.keys(document).length === 0 && document.constructor === Object)) {
                        logger.error('Seems like the record is not getting updated. Kindly check Collection.');
                    } else if (document.value === null) {
                        // In upsert, if record is created then document returned is null.
                        logger.error('Seems like the record is inserted at Backend.');
                    } else {
                        logger.error(`document saved successfully!!`, jsonObj.metername);
                        document.value.type = this.type;
                        const str = JSON.stringify(document.value);
                        super.publish(str);
                        //super.publishAggreationFacts(str);
                    }
                    resolve();
                });
            });
        } catch (error) {
            logger.error("Error while processing." + error + JSON.stringify(error));
            return;
        }
    }
  
    isValid(jsonObj) {
        if (jsonObj.aggregate) {
          return true;
        }
        return false;
    }

    /**
     * Get Query Condition for mongodb.
     * 
     * @param {object} jsonObj 
     */
    getCondition(jsonObj) {
        return  this.storeCondition(jsonObj);
    }

    /**
     * Get operator to work on update query for mongodb.
     * 
     * @param {object} jsonObj 
     */
    getOperator(jsonObj) {
        const lastUpdatedAt = new Date();
        let value = {
            "$inc": {
              "h_sum": jsonObj.value,
              "count": 1
            },
            "$min": {
              "h_min": jsonObj.value
            },
            "$max": {
              "h_max": jsonObj.value
            },
            $set: {
              "updatedAt": lastUpdatedAt,
              "displayHour": jsonObj.displayHour,
              "date": jsonObj.date,
              "updatedAtTimestamp": lastUpdatedAt.getTime()
            }
        }
        logger.trace("OPERATOR: " + JSON.stringify(value));
        return value;
    }

    /**
     * Store condition and return the same object.
     * 
     */
    storeCondition(jsonObj) {
        const value = {
            "customerId": jsonObj.customerId,
            "siteId": jsonObj.siteId,
            "elementName": 'process',
            "lineid": jsonObj.lineid,
            "sublineid": jsonObj.sublineid,
            "stationid": jsonObj.stationid,
            "substationid": jsonObj.substationid,
            "parametername": jsonObj.parametername,
            "min": jsonObj.min,
            "max": jsonObj.max,
            "criticalmin": jsonObj.criticalmin,
            "criticalmax": jsonObj.criticalmax,
            "year": jsonObj.year,
            "month": jsonObj.month,
            "day": jsonObj.day,
            "hour": jsonObj.hour,
            "week": jsonObj.week
        }
        return value;
    }
}

module.exports = ConsumerProcessHourly;
