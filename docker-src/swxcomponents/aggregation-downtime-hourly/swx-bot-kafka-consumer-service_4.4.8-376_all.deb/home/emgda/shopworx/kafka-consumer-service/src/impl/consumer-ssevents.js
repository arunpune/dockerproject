const config = require('../../config/config.json');
const Consumer = require('../base/consumer.js');
const utility = require('../utils/utility.js');
const bunyan = utility.bunyan;

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'consumer-ssevents',
    level: config.logLevel
});

/**
 * Consumer Implementation.
 */
class ConsumerSSEvents extends Consumer {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning,  maxBytesPerPartition, kafkaLogLevel) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning,  maxBytesPerPartition, kafkaLogLevel);
        logger.error('Consumer to Server Sent Events flow initialised.');
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        utility.publishSSEvent(message);
    }
}

module.exports = ConsumerSSEvents;