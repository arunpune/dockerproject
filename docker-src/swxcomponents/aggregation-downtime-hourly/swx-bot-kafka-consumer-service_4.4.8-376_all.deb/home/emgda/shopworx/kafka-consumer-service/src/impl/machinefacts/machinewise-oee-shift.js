const config = require('../../../config/config.json');
const Aggregation = require('../../base/aggregation.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'machinewise-oee-shift',
    level: config.logLevel
});

/**
 * Aggregation Implementation.
 */
class MachinewiseOEEShift extends Aggregation {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
        this.collectionName = 'machinewise-oee-shift';
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     * 
     */
    async initDB() {
        await super.initDB();
        logger.error('Consumer to Machinewise OEE shift service flow initialised.');
        return 0;
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        try {
            const jsonObj = JSON.parse(message);
            if (!this.isValid(jsonObj)) {
                logger.trace('Skipping as data did not pass validation.');
                return;
            }
            const collection = this.db.collection(this.collectionName);
            return new Promise((resolve, reject) => { 
                collection.findOneAndUpdate(this.getCondition(jsonObj), this.getOperator(jsonObj), { "upsert": true, returnOriginal: false }, (err, document) => {
                    if (err) {
                        logger.fatal("Error occured while upsert to machine-oee-shift collection : " + JSON.stringify(err));
                    } else if (!document || (Object.keys(document).length === 0 && document.constructor === Object)) {
                        logger.error('Seems like the record is not getting updated. Kindly check Collection.');
                    } else if (document.value === null) {
                        // In upsert, if record is created then document returned is null.
                        logger.error('Seems like the record is inserted at Backend.');
                    } else {
                        logger.error('Records upsert to machine-oee-shift collection.');
                    }
                    resolve();
                });
            });
        } catch (error) {
            logger.error("Error while processing." + error + JSON.stringify(error));
            return;
        }
    }

    isValid(jsonObj) {
        return true;
    }

    /**
     * Get Query Condition for mongodb.
     * 
     * @param {object} jsonObj 
     */
    getCondition(jsonObj) {
        const condition = {
            "customerId": jsonObj.customerId,
            "siteId": jsonObj.siteId,
            "machinename": jsonObj.machinename,
            "date": jsonObj.date,
            "year": jsonObj.year,
            "month": jsonObj.month,
            "day": jsonObj.day,
            "week": jsonObj.week,
            "shift": jsonObj.shiftName || jsonObj.shift
        };
        logger.error(`CONDITION: ${JSON.stringify(condition)}`);
        return condition;
    }

    /**
     * Get operator to work on update query for mongodb.
     * 
     * @param {object} jsonObj
     */
    getOperator(jsonObj) {
        const time = new Date();
        const timestamp = time.getTime();
        let value = {
            $set: {
                "runtime": jsonObj.runtime || 0,
                "availability": jsonObj.availability || 0,
                "performance": jsonObj.performance || 0,
                "quality": jsonObj.quality || 0,
                "oee": jsonObj.oee || 0,
                "type": jsonObj.type,
                "produced": jsonObj.qty || 0,
                "rejected": jsonObj.rqty || 0,
                "shiftAvailableTime": parseFloat(jsonObj.shiftAvailableTime),
                "target": jsonObj.targetQty || 0,
                "updatedAt": time,
                "updatedAtTimestamp": timestamp
            },
        }
        logger.trace("OPERATOR: " + JSON.stringify(value));
        return value;
    }
}

module.exports = MachinewiseOEEShift;