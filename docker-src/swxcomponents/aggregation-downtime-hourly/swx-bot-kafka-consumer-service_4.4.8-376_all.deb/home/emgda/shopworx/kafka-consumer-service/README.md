# Kafka Consumer Service

 Introduction
 ------------
 
1. This service is a boiler-plate to start listening over a topic.
2. The goal is to consume the message from a partition (can be more than one) of a specified topic and do some processing.
3. After the process is done the output can be then produced over a specified topic.
4. User must carefully provide configuration parameters to make service work smoothly.
5. The processing logic can be written inside the `process()` method of class `Consumer` inside file `consumer.js`.
6. One can clone this repository and start an extension of capabilities on top of this service.

configuration parameters description
 -------------------


| configuration parameter  | Description  | Default value | Examples |
| :---------------------- |:-------------| :-------| :-------|
| `kafkaLogLevel`     | Kafka Log level | 1 | 0 = NOTHING, 1 = ERROR , 2 = WARN, 4 = INFO, 5 = DEBUG
| `logLevel`      | log level for application  |  error | fatal, error, warn, debug, info, trace
| `isProducerEnabled` | Where a producer is enabled | false | true, false
| `instanceType` | Type of instance to be created to initiate different flows | `consumer` | `consumer`, `aggregate-cycletime-hourly`, `aggregate-downtime-hourly`, `aggregate-rejection-hourly`, `consumer-cycletime-shift`, `aggregate-downtime-shift`, `aggregate-rejection-shift`, `transformation-asset-state-hourly`, `transformation-asset-state-shift`, `aggregate-process-data-hourly`, `aggregate-process-data-shift`, `aggregate-cycletime-plan`, `aggregate-downtime-plan`, `aggregate-rejection-plan`, `transformation-asset-state-plan`, `machinewise-oee-hourly`, `machinewise-oee-shift`
| `cacheExpiryInHours` | expiry (in hours) of the cache used for in-memory performance. All the update conditions and operator are cache so that it does not create unncessary objects with same property. Hence, picked up from cache | `2` | `2`, `2`
| `mongo.url` | complete url to connect mongo | `mongodb://emgda:Entrib!23@localhost:27017,localhost:27018,localhost:27019/emgda?replicaSet=rs0` | `mongodb://192.168.1.111:27017`
| `mongo.dbName` | name of database in mongdb you wish to communicate with. DO not change default value unless reviewed and discussed. | `emgda` | Any String
| `mongo.options.poolSize` | When service starts, it starts with the pool of threads to communicated to MongoDB. | `30` | `5`, `20`, `50`
| `mongo.options.connectTimeoutMS` | Value in milliseconds after which the atteampt to establish connection with MongoDB times out and terminates application if times out. | `10000` | `50000`, `20000`
| `mongo.options.useUnifiedTopology` | A boolean value to indicate whether to use unified topology. If set to `false`, it throws warning on console to set it to `true` | `true` | `true` OR `false`
| `mongo.options.readPreference` | A String property to specify whether to use what should be the read preference by Client. | `secondaryPreferred` | `primary`, `primaryPreferred`, `secondary`, `secondaryPreferred` and `nearest`
| `consumer.brokerlist` | list of clustered Kafka brokers. it comprises of array of `<IP_ADDRESS>:<port>` | ["localhost:9092"] | ["localhost:9092", "localhost:9093", "localhost:9094"]
| `consumer.clientId` | clientId for the consumer that belongs to a certain group| `microservicename-consumer-1` | `aggregation-cycletime-hourly-consumer-1`
| `consumer.groupId` | groupId for the consumer | `microservicename-group` | `aggregation-cycletime-hourly-consumer-group`
| `consumer.topicName` | name of the topic on which consumer is listening | `consumerTopicName` | `aggregation-cycletime-hourly`
| `consumer.isReadFromBeginning` | Whether to read the topic from beginning. Currently this will not work as by default we have allowed consumer to auto-commit messages | false | true, false
| `consumer.isbatchEnabled` | Whether to enable batch consumption. If `false` then individual messages are entertained by the consumer. | false | true, false
| `consumer.maxBytesPerPartition` | A number in bytes to restrict the intake of messages at partition level. Every partition of a topic is assigned this size. | 1048576 | Any non-negative and valid integer value.
| `producer.brokerlist` | list of clustered Kafka brokers. it comprises of array of `<IP_ADDRESS>:<port>` | ["localhost:9092"] | ["localhost:9092", "localhost:9093", "localhost:9094"]
| `producer.clientId` | clientId for the Producer that belongs to a certain group| `microservicename-producer-1` | `transformation-cycletime-hourly-producer-1`
| `producer.topicName` | name of the topic on which producer shall publish message | `producerTopicName` | `transformation-cycletime-hourly`
| `event.sse.endpoint` | endpoint where user must hit. Consider example, http://localhost:3000/sse/{:PlugId}. Do not change this unless required. | `sse` | `sse`
| `event.sse.port` | port where server msut start. Consider example, http://localhost:3000/sse/{:PlugId}. Do not change this unless required. | 3000 | Any valid port number.
| `event.sse.emitterName` | Name of the emitter where the data would be pusblish using `emitter.push`. This is the point where SSE event module listens in the emitter using `emitter.on` | `kafka-consumer-to-sse-event-app` | `some_meaning_name`
 

Pre-requisites
 ------------
 1. Please make sure that `node version 10.x.x` OR greater (stable) release is on the path.
 2. Please make sure you fill appropriate configurations in `config.json` file.
 2. Please avoid using same service with same configuration file on same machine.
 3. Please ensure that the topic is already created using specific command in production mode. 
 2. Cross verify the topic and no. of partitions for the same.
 3. If you do not create partitions for the topic and the producer is run, then it creates a single partition enabled topic. Then you will have to run command to dynamically increase the partitions for a topic. This is easy process.
 
 Installation in QA / DEPLOYMENT
 ------------
1. Use the debian file and follow the generic process to install the debian.
2. A new systemd file shall be created at location `/lib/systemd/system/swx-bot-kafka-consumer-service-boilerplate.service`.
3. A project file is created at location /home/emgda/shopworx/kafka-consumer-service-boilerplate/
4. Make sure you add an entry for this application to the monit file at location `/etc/monit/monitrc` using sudo permissions and reload monit using command `sudo monit reload`. Now monit must also monitor this service's health.
5. Make sure you add the entry for this application in the file `/home/emgda/shopworx/scripts/checkrun.sh` because the crontab runs every 1 minute and this shell file is run respectively, if this service is down then it will be started again. The entire health monitoring shall be taken care by monit and you can view the GUI from M/Monit login.


Installation in DEV
 ------------
 checkout the project and go into the project main directory and run command below sequentially.
 1. `npm install` [**Note**: Use this command only once.]
 2. `node index.js`

Who do I talk to?
----------------
**Product** - Ankur Soni **<asoni@entrib.com>**
**Product peer** - Ankit Jain **<ajain@entrib.com>**
**Manager** - Kiran Nataraj **<kiran@entrib.com>**