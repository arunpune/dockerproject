const config = require('../../../config/config.json');
const Aggregation = require('../../base/aggregation.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const HTTP_SUCCESS_CODE = 200;
/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'consumer-cycletime-hourly',
    level: config.logLevel
});

/**
 * Aggregation Implementation.
 */
class ConsumerCycletimeHourly extends Aggregation {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
        this.collectionName = 'aggregatehourly';
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     * 
     */
    async initDB() {
        await super.initDB();
        logger.error('Consumer to Cycletime hourly aggregation service flow initialised.');
        return 0;
    }

    /**
     * Populate all asset related data by calling an API and storing them in memory.
     */
    async initAssets() {
        // call API 
        const credentials = config.client.credentials;
        let response = await utility.getAuth(credentials, { 'loginType': 'ORIGIN' });
        if (!response || !response.status || HTTP_SUCCESS_CODE !== response.status) {
            logger.error(`Error in authentication to server ${JSON.stringify(response.data)}`);
            this.retryInitAsset();
        }
        logger.trace('Successfully authenticate to server.');
        response = await utility.getAsset({ 'sessionId': response.data.sessionId });
        if (!response || !response.status || HTTP_SUCCESS_CODE !== response.status || !response.data.results) {
            logger.error(`Error while getting assets ${JSON.stringify(response.data)}`);
            this.retryInitAsset();
        }
        logger.trace('Settings Assets.');
        utility.setAssets(response.data.results);
        // GET last operator details for site and machine.
        await utility.getLastOperatorDetails(this.db);
    }

    async retryInitAsset() {
        await utility.sleep(5000);
        await this.initAssets();
        return;
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        try {
            const jsonObj = JSON.parse(message);
            if (!this.isValid(jsonObj)) {
                logger.trace('Skipping as data did not pass validation.');
                return;
            }
            const collection = this.db.collection(this.collectionName);
            return new Promise((resolve, reject) => { 
                collection.findOneAndUpdate(this.getCondition(jsonObj), this.getOperator(jsonObj), { "upsert": true, returnOriginal: false }, (err, document) => {
                    if (err) {
                        logger.fatal("Error occured while upsert to aggregation collection : " + JSON.stringify(err));
                    } else if (!document || (Object.keys(document).length === 0 && document.constructor === Object)) {
                        logger.error('Seems like the record is not getting updated. Kindly check Collection.');
                    } else if (document.value === null) {
                        // In upsert, if record is created then document returned is null.
                        logger.error('Seems like the record is inserted at Backend.');
                    } else {
                        const str = JSON.stringify(document);
                        super.publish(str);
                        //super.publishAggreationFacts(str);
                    }
                    resolve();
                });
            });
        } catch (error) {
            logger.error("Error while processing." + error + JSON.stringify(error));
            return;
        }
    }

    isValid(jsonObj) {
        if (jsonObj.elementName === 'cycletime') {
          const obj = utility.getAssets().find(o => o.id === jsonObj.assetid);
          if (!obj) {
              logger.error("No relevant object identified while checking asset.");
              return false;
          }
          const assetName = obj.assetName;
          // check for Injection Moulding
          if ('injectionmolding' === assetName) {
              return this.validateInjectionMolding(jsonObj);
          }
          // check for press
          else if ('press' === assetName) {
              return this.validatePress(jsonObj);
          }
          // check for cnc
          else if ('cnc' === assetName) {
              return this.validateCnc(jsonObj);
          }
          else {
            return false;
          }
        } else if (jsonObj.elementName === 'operatorlog') {
          /**
           * If valid operator data (i.e operator has logged in to a machine),
           * Update Machine Operator Map with new operator details.
           */
          if (this.validateOperatorDetails(jsonObj)) {
            const key = `${jsonObj.siteId}_${jsonObj.machinename}`
            const machineOperatorMap = {
                key,
                value: {
                    operatorName: jsonObj.operatorname,
                   operatorId: jsonObj.operatorid,
                }
            }
            utility.setMachineOperatorMap(machineOperatorMap);
            return false;
          }
          return false;
        } else {
          return false;
        }
    }

    /**
     * Validate entries for Injection Molding Machine production record.
     * 
     * @param {object} jsonObj
     */
    validateInjectionMolding(jsonObj) {
        logger.trace("Asset identified: injectionmolding");
        return (jsonObj.hasOwnProperty("cycletimeinms") && jsonObj.hasOwnProperty("cycleendtime"));
    }

    /**
     * Validate entries for Press Machine production record.
     * 
     * @param {object} jsonObj 
     */
    validatePress(jsonObj) {
        logger.trace("Asset identified: press");
        return (jsonObj.hasOwnProperty("cycletimeinms") && jsonObj.hasOwnProperty("cycleendtime"));
    }

    /**
     * Validate entries for CNC Machine production record.
     * 
     * @param {object} jsonObj 
     */
    validateCnc(jsonObj) {
        logger.trace("Asset identified: cnc");
        return (jsonObj.hasOwnProperty("cycletimeinms") && jsonObj.hasOwnProperty("cycleendtime"));
    }

    /**
     * Validate entries for operator record.
     * 
     * @param {object} jsonObj 
     */
     validateOperatorDetails(jsonObj) {
        logger.trace("Validating Operator details.");
        return (jsonObj.hasOwnProperty("operatorname") && jsonObj.hasOwnProperty("operatorid") && jsonObj.hasOwnProperty("signintime") && jsonObj.hasOwnProperty("status") && !jsonObj.hasOwnProperty("signouttime"));
    }

    /**
     * Get Query Condition for mongodb.
     * 
     * @param {object} jsonObj 
     */
    getCondition(jsonObj) {
        const key = utility.buildHourlyConditionKey(jsonObj);
        return this.storeCondition(key, jsonObj);
    }

    /**
     * Get operator to work on update query for mongodb.
     * 
     * @param {object} jsonObj 
     */
    getOperator(jsonObj) {
        const { trial, purge } = jsonObj;
        const standardCyleTime = jsonObj.stdcycletime * 1000;
        const cycletimeDuration = jsonObj.cycletimeinms;
        const lastUpdatedAt = new Date();
        let operatorData = utility.getMachineOperatorMap();
        const key = `${jsonObj.siteId}_${jsonObj.machinename}`;
        operatorData = operatorData.get(key);
        let operatorName = '-';
        if(operatorData && operatorData.operatorId) {
            operatorName = operatorData.operatorName;
        }
        let incPayload = {
            "sctm_count": 1,
            "actm_count": 1,
            "sctm_sum": standardCyleTime,
            "actm_sum": cycletimeDuration
        };
        if (purge) {
            incPayload = {
                ...incPayload,
                "purge_qty": jsonObj.quantity,
                "purge_actm_sum": cycletimeDuration,
            };
        } else {
            incPayload = {
                ...incPayload,
                "qty": jsonObj.quantity,
            };
        }
        let value = {
            "$inc": incPayload,
            "$max": {
                "sctm_max": standardCyleTime,
                "actm_max": cycletimeDuration
            },
            "$min": {
                "sctm_min": standardCyleTime,
                "actm_min": cycletimeDuration
            },
            $set: {
                "trial": trial || false,
                "updatedAt": lastUpdatedAt,
                "actm": cycletimeDuration,
                "date": jsonObj.date,
                "shift": jsonObj.shiftName,
                "cycleendtime": jsonObj.cycleendtime,
                "cavity": jsonObj.cavity,
                "operatorname": operatorName,
                "displayHour": jsonObj.displayHour,
                "hourlyBreakTime" : parseInt(jsonObj.hourlyBreakTime, 10),
                "hourlyAvailableTime" : parseInt(jsonObj.hourlyAvailableTime, 10),
                "updatedAtTimestamp": lastUpdatedAt.getTime()
            },
            $setOnInsert: {
                "cyclestarttime": jsonObj.cyclestarttime
            }
        }
        logger.trace("OPERATOR: " + JSON.stringify(value));
        return value;
    }

    /**
     * Store condition and return the same object.
     * 
     * @param {string} key
     */
    storeCondition(key, jsonObj) {
        let operatorData = utility.getMachineOperatorMap();
        const identifier = `${jsonObj.siteId}_${jsonObj.machinename}`;
        operatorData = operatorData.get(identifier);
        let operatorId = '-';
        if(operatorData && operatorData.operatorId) {
            operatorId = operatorData.operatorId;
        }
        const value = {
            "customerId": jsonObj.customerId,
            "siteId": jsonObj.siteId,
            "elementName": jsonObj.elementName,
            "machinename": jsonObj.machinename,
            "planid": jsonObj.planid,
            "partname": jsonObj.partname,
            "operatorid": operatorId,
            "year": jsonObj.year,
            "month": jsonObj.month,
            "day": jsonObj.day,
            "hour": jsonObj.hour,
            "week": jsonObj.week,
            "sctm": jsonObj.stdcycletime * 1000,
            "activecavity": jsonObj.activecavity
        }
        return value;
    }
}

module.exports = ConsumerCycletimeHourly;
