const bunyan = require('bunyan');
const EventEmitter = require('eventemitter3');
const eventEmitter = new EventEmitter();
const registry = require('./registry.js');
const CONFIG = require('../../config/config.json');
const MongoClient = require('mongodb').MongoClient;
const axios = require('axios');

const host = CONFIG.server.hostname;
const port = CONFIG.server.port;

const colon = ':';
let assets = {};
let machineOperatorMap = new Map();

const INVALID_PAYLOAD_IN_REQUEST = 400;
const INTERNAL_SERVER_ERROR = 500;

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'utility',
    level: CONFIG.logLevel
});

const NOTIFICAITON_TOPICS = {
    PUSH: "notification-sse",
    EMAIL: "notification-email",
    SMS: "notification-sms"
};


const authenticate = async (eventName, req, res) => {
    logger.trace('Server hit.');
    logger.error('Authenticating request.');
    // get my details
    logger.trace(`Request headers: + ${JSON.stringify(req.headers)}`);
    const cookie = req.headers.cookie;
    //Cookie: sessionId=C25275CACF9808FA6DF18B8F80BDF616.tomcat1; locale=zhHans
    logger.trace(`Cookie: ${cookie}`);
    const splittedStr = cookie.split(';');
    let index = splittedStr.findIndex(element => element.includes("sessionId"));
    if (index < 0) {
        sendError(res, INVALID_PAYLOAD_IN_REQUEST, "Session Id not identified.", "INVALID_SESSION");
        return;
    }
    const newCookieValue = splittedStr[index];
    if (!newCookieValue || newCookieValue.split('=').length !== 2) {
        sendError(res, INVALID_PAYLOAD_IN_REQUEST, "Invalid session identified.", "INVALID_SESSION");
        return;
    }
    const sessionId = newCookieValue.split('=')[1];
    logger.trace(`Session ID: ${sessionId}`);
    const cookieString = "JSESSIONID=" + sessionId + "; sessionId=" + sessionId + ";";
    const response = await axios.get(getMyDetailsURL(), { headers: { 'Cookie': cookieString, 'sessionId': sessionId } }, { withCredentials: true }).catch((error) => {
        logger.error(`Error while getting my details from server: ${JSON.stringify(error)}`);
    });
    if (!response) {
        sendError(res, INTERNAL_SERVER_ERROR, "Some error occured at server.", INTERNAL_SERVER_ERROR);
        return;
    }
    logger.trace('Some response identified from server.');
    if (response.data.errors) {
        sendError(res, INTERNAL_SERVER_ERROR, response.data.errors, INTERNAL_SERVER_ERROR);
        return;
    }
    res.writeHead(200, SSE_RESPONSE_HEADER);
    const results = response.data.results;
    logger.trace(`Response identified from server: ${JSON.stringify(results)}`);
    setEventListener(eventName, req, res, results);
}

const setEventListener = (eventName, req, res, results) => {
    getEmitter().on(eventName, (data) => {
        streamEvent(data, results, res, eventName);
    });
    // streamEvent(JSON.stringify(data), null, res, eventName);
    req.on("close", () => { logger.error('Connection closed'); });
    req.on("end", () => { logger.error('Connection ended'); });
    req.on("timout", () => { logger.error('Connection ended for plugID'); });
    req.on("error", (e) => { logger.error(`Connection error occured for plugID: ${JSON.stringify(e)}`); });
}

const isSameUserID = (jsonData, results) => {
    const myUserId = `${jsonData.userid}`;
    const requestUserId = `${results.user.id}`;
    const bool = myUserId == requestUserId;
    logger.trace(`Comparing PlugID: ${myUserId} === ${requestUserId} = ${bool}`);
    return bool;
}

const streamEvent = (data, results, res, eventName) => {
    let jsonData = {};
    try {
        jsonData = JSON.parse(data);
    } catch (error) {
        logger.error(`Data received for publishing on SSE was not JSON: ${JSON.stringify(data)}`);
        return;
    }
    logger.trace(`Data received | emitter name : ${eventName}`);
    if (isSameUserID(jsonData, results)) {
        logger.trace("Writing Data.");
        res.write('retry: 500\n');
        res.write(`event: notification\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
    } else {
        logger.info(`Returning as user ids did not match.`);
    }
}

const fillTemplate = (template, message) => {
    let filledTemplate = template.replace(/{([^{}]+)}/g, function (keyExpr, key) {
        return message[key] || "";
    });
    return filledTemplate;
}

const getSendEmailURL = () => {
    const URL = `http://${host}:${port}/server/email/false`;
    logger.trace(`getSendEmailURL: ${URL}`);
    return URL;
}
const sendEmail = async (message, headers) => {
    return await axios.post(getSendEmailURL(), message, { headers })
        .catch((error) => {
            logger.error(`Exception while authenticating: ${JSON.stringify(error)}`);
        });
}

const getSendSMSURL = () => {
    const URL = `http://${host}:${port}/server/sms`;
    logger.trace(`getSendSMSURL: ${URL}`);
    return URL;
}

const sendSMS = async (message, headers) => {
    return await axios.post(getSendSMSURL(), message, { headers })
        .catch((error) => {
            logger.error(`Exception while authenticating: ${JSON.stringify(error)}`);
        });
}

const handlerAlarmRequest = async (req, res) => {
    authenticate("alarm", req, res);
}

/** @constant {Object} */
const DATA_TYPE = {
    STRING: "string",
    NUMBER: "number",
    BOOLEAN: "boolean",
    OBJECT: "object"
};

/** @constant {Object} SSE_RESPONSE_HEADER response header for sever-sent events*/
const SSE_RESPONSE_HEADER = {
    'Connection': 'keep-alive',
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'X-Accel-Buffering': 'no'
};

/** @constant {Object} SSE_RESPONSE_HEADER response header for sever-sent events*/
const CUSTOMERWISE_BUSINESS_HOURS_AGGREGATION_QUERY = [
    {
        $match: {
            "elementName": "businesshours",
            "sortindex": 1
        }
    },
    {
        $group: {
            "_id": {
                "id": "$_id",
                "customerId": "$customerId",
                "siteId": "$siteId"
            },
            "starttime": { "$first": '$starttime' }
        }
    },
    {
        $project: {
            "_id": "$_id.id",
            "customerId": "$_id.customerId",
            "siteId": "$_id.siteId",
            "starttime": "$starttime",
        }
    }
];

/** @constant {Object} SSE_RESPONSE_HEADER response header for sever-sent events*/
const CUSTOMERWISE_SHIFT_BRACKET_QUERY = [
    {
        $match: {
            "elementName": "businesshours"
        }
    },
    { $sort: { "sortindex": 1 } },
    {
        $group: {
            "_id": {
                "customerId": "$customerId",
                "siteId": "$siteId",
                "shift": "$shift"
            },
            "starttime": { '$first': '$starttime' },
            "endtime": { '$last': '$endtime' },
            "hours": { '$sum': '$duration' }
        }
    },
    {
        $project: {
            "customerId": "$_id.customerId",
            "shift": "$_id.shift",
            "siteId": "$_id.siteId",
            "starttime": "$starttime",
            "endtime": "$endtime",
            "hour": { $divide: ["$hours", 3600000] }
        }
    }
];

const sendError = (res, status, errorMessage, errorCode) => {
    logger.error('Error identifed.');
    res.status(status);
    const payload = { errorMessage, errorCode };
    res.send(JSON.stringify(payload));
}

/**
 * Get emitter.
 */
const getEmitter = () => {
    return eventEmitter;
}

/**
* Utility method declaration and definition for re-usability
* Important imports 
*/
const drawLine = () => {
    logger.error('--------------------------------------------------------');
}

/**
 * Checks if give configuration parameter exists with given data types. If no then exit node js service 
 * pointing deficiency in perticular parameter.
 * 
 * @param {string} configParam 
 * @param {string} dataType 
 */
const checkIfExists = (configParam, configParamString, dataType) => {
    // check if configuration parameter exists in configuration file.
    if (typeof configParam != 'boolean' && !configParam) {
        logger.fatal("Configuration parameter not set: " + configParamString);
        process.exit(1);
    }
    // check if configuration parameter has valid data type.
    if (typeof configParam != dataType) {
        logger.fatal("Data type for configuration parameter '" + configParamString + "' must be: " + dataType);
        process.exit(1);
    }
}

/**
 * validate the configuration parameter is valid with given conditions
 * 
 */
const validateConfigfileParameters = () => {

    checkIfExists(CONFIG.kafkaLogLevel, "CONFIG.kafkaLogLevel", DATA_TYPE.NUMBER);
    if (CONFIG.kafkaLogLevel < 0 || CONFIG.kafkaLogLevel > 5) {
        logger.fatal("Configuration value incorrect for parameter : CONFIG.kafkaLogLevel");
        process.exit(1);
    }
    checkIfExists(CONFIG.logLevel, "CONFIG.logLevel", DATA_TYPE.STRING);
    checkIfExists(CONFIG.isProducerEnabled, "CONFIG.isProducerEnabled", DATA_TYPE.BOOLEAN);
    checkIfExists(CONFIG.instanceType, "CONFIG.instanceType", DATA_TYPE.STRING);
    const reg = registry.getRegistry();
    if (!Object.values(reg).includes(CONFIG.instanceType)) {
        logger.fatal("value received is " + CONFIG.instanceType +
            " in CONFIG.instanceType, but must be one of : " + Object.values(reg));
        process.exit(1);
    }
    checkIfExists(CONFIG.cacheExpiryInHours, "CONFIG.cacheExpiryInHours", DATA_TYPE.NUMBER);

    checkIfExists(CONFIG.mongo, "CONFIG.mongo", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.mongo.url, "CONFIG.mongo.url", DATA_TYPE.STRING);
    checkIfExists(CONFIG.mongo.dbName, "CONFIG.mongo.dbName", DATA_TYPE.STRING);
    checkIfExists(CONFIG.mongo.options, "CONFIG.mongo.options", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.mongo.options.poolSize, "CONFIG.mongo.options.poolSize", DATA_TYPE.NUMBER);
    checkIfExists(CONFIG.mongo.options.useUnifiedTopology, "CONFIG.mongo.options.useUnifiedTopology", DATA_TYPE.BOOLEAN);
    checkIfExists(CONFIG.mongo.options.readPreference, "CONFIG.mongo.options.readPreference", DATA_TYPE.STRING);

    checkIfExists(CONFIG.consumer, "CONFIG.consumer", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.consumer.brokerlist, "CONFIG.consumer.brokerlist", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.consumer.clientId, "CONFIG.consumer.clientId", DATA_TYPE.STRING);
    checkIfExists(CONFIG.consumer.groupId, "CONFIG.consumer.groupId", DATA_TYPE.STRING);
    checkIfExists(CONFIG.consumer.topicName, "CONFIG.consumer.topicName", DATA_TYPE.STRING);
    checkIfExists(CONFIG.consumer.isReadFromBeginning, "CONFIG.consumer.isReadFromBeginning", DATA_TYPE.BOOLEAN);
    checkIfExists(CONFIG.consumer.isBatchEnabled, "CONFIG.consumer.isBatchEnabled", DATA_TYPE.BOOLEAN);
    checkIfExists(CONFIG.consumer.maxBytesPerPartition, "CONFIG.consumer.isBatchEnabled", DATA_TYPE.NUMBER);
    // checkIfExists(CONFIG.consumer.autoCommit, "CONFIG.consumer.autoCommit", DATA_TYPE.BOOLEAN);

    checkIfExists(CONFIG.producer, "CONFIG.consumer", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.producer.brokerlist, "CONFIG.producer.brokerlist", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.producer.clientId, "CONFIG.producer.clientId", DATA_TYPE.STRING);
    checkIfExists(CONFIG.producer.topicName, "CONFIG.producer.topicName", DATA_TYPE.STRING);
};

/**
 * 
 * self running module. This will be loaded only once.
 * 
 */
(() => {
    drawLine();
    logger.error("Validating configuration parameters.");
    drawLine();
    validateConfigfileParameters();
    logger.error("Validated configuration parameters successfully.");
    drawLine();
})();

const setEventEmitter = (req, res, results) => {
    eventEmitter.on(CONFIG.events.sse.emitterName, (data) => {
        let jsonData = {};
        try {
            jsonData = JSON.parse(data);
        } catch (error) {
            logger.error("Data received for publishing on SSE was not JSON.");
            return;
        }
        logger.trace(`DATA received from topic.`);
        // Pass only data relevant to a particular customer with certain site ID.
        const myPlugId = jsonData.customerId + '-' + jsonData.siteId;
        const requestPlugId = results.customer.id + '-' + results.activeSiteId;
        if (data && myPlugId === requestPlugId) {
            logger.trace("Writing Data.");
            res.write('retry: 500\n');
            res.write(`event: ${jsonData.type}\n`);
            res.write(`data: ${JSON.stringify(data)}\n\n`);
        } else {
            logger.error(`Could not find proper endpoint match. Payload data: ${myPlugId}, Request data: ${requestPlugId}`);
        }
    });
    req.on("close", () => { logger.error('Connection closed'); });
    req.on("end", () => { logger.error('Connection ended'); });
    req.on("timout", () => { logger.error('Connection ended for plugID'); });
    req.on("error", (e) => { logger.error(`Connection error occured for plugID: JSON.stringify(e))`); });
}

/**
 * Handle Request that comes by hitting an endpoint on an express server.
 * This is specific to Server Sent Events.
 * 
 * @param {object} req 
 * @param {object} res 
 */
const handleASMRequest = async (req, res) => {
    logger.trace('Server hit.');
    logger.error('Authenticating request.');
    // get my details
    logger.trace(`Request headers: + ${JSON.stringify(req.headers)}`);
    const cookie = req.headers.cookie;
    logger.trace(`Cookie: ${cookie}`);
    if (!cookie || cookie.split('=').length !== 2) {
        sendError(res, INVALID_PAYLOAD_IN_REQUEST, "Invalid session identified.", "INVALID_SESSION");
        return;
    }
    const sessionId = cookie.split('=')[1];
    logger.trace(`Session ID: ${sessionId}`);
    const response = await axios.get(getMyDetailsURL(), { "headers": { sessionId } }).catch((error) => {
        logger.error(`Error while getting my details from server: ${JSON.stringify(error)}`);
    });
    if (!response) {
        sendError(res, INTERNAL_SERVER_ERROR, "Some error occured at server.", INTERNAL_SERVER_ERROR);
        return;
    }
    logger.trace('Some response identified from server.');
    if (response.data.errors) {
        sendError(res, INTERNAL_SERVER_ERROR, response.data.errors, INTERNAL_SERVER_ERROR);
        return;
    }
    res.writeHead(200, SSE_RESPONSE_HEADER);
    const results = response.data.results;
    logger.trace(`Response identified from server: ${JSON.stringify(results)}`);
    setEventEmitter(req, res, results);
}

/**
 * Publish an Server Sent event. This is expected to be called from ConsumerSSEvents class.
 * 
 * @param {object} eventData 
 */
const publishSSEvent = (eventData) => {
    logger.info("Publishing Server Sent Events.");
    eventEmitter.emit(CONFIG.events.sse.emitterName, eventData);
}

/**
 * concat comma separated string as arguments
 */
const concat = (...theArgs) => {
    return theArgs.reduce((prev, cur) => prev + cur);
}

/**
 * Build condition key for logging purpose.
 * 
 * @param {object} jsonObj 
 */
const buildConditionKey = (jsonObj) => {
    let key = concat(
        jsonObj.customerId, colon,
        jsonObj.siteId, colon,
        jsonObj.elementName, colon,
        jsonObj.machinename, colon,
        jsonObj.planid);
    logger.trace('Key: ' + key);
    return key;
}

/**
 * 
 * @param {object} jsonObj 
 */
const buildHourlyConditionKey = (jsonObj) => {
    const identifier = `${jsonObj.siteId}_${jsonObj.machinename}`;
    const operatorData = machineOperatorMap.get(identifier);
    let operatorId = '-';
    if (operatorData && operatorData.operatorId) {
        operatorId = operatorData.operatorId;
    }
    const key = concat(
        jsonObj.customerId, colon,
        jsonObj.siteId, colon,
        jsonObj.elementName, colon,
        jsonObj.machinename, colon,
        jsonObj.planid, colon,
        jsonObj.partname, colon,
        operatorId, colon,
        jsonObj.year, colon,
        jsonObj.month, colon,
        jsonObj.day, colon,
        jsonObj.hour, colon,
        jsonObj.week, colon,
        (jsonObj.stdcycletime * 1000), colon,
        jsonObj.activecavity
    );
    logger.trace('Key: ' + key);
    return key;
}

/**
 * 
 * @param {object} jsonObj 
 */
const buildShiftWiseConditionKey = (jsonObj) => {
    const identifier = `${jsonObj.siteId}_${jsonObj.machinename}`;
    const operatorData = machineOperatorMap.get(identifier);
    let operatorId = '-';
    if (operatorData && operatorData.operatorId) {
        operatorId = operatorData.operatorId;
    }
    const key = concat(
        jsonObj.customerId, colon,
        jsonObj.siteId, colon,
        jsonObj.elementName, colon,
        jsonObj.machinename, colon,
        jsonObj.planid, colon,
        jsonObj.partname, colon,
        operatorId, colon,
        jsonObj.year, colon,
        jsonObj.month, colon,
        jsonObj.day, colon,
        jsonObj.week, colon,
        (jsonObj.stdcycletime * 1000), colon,
        jsonObj.shift || jsonObj.shiftName, colon,
        jsonObj.activecavity);
    logger.trace('Key: ' + key);
    return key;
}

/**
 * 
 * @param {object} jsonObj 
 */
const buildPlanWiseConditionKey = (jsonObj) => {
    let key = concat(
        jsonObj.customerId, colon,
        jsonObj.siteId, colon,
        jsonObj.elementName, colon,
        jsonObj.planid, colon,
        jsonObj.partname, colon,
        (jsonObj.stdcycletime * 1000), colon,
        jsonObj.activecavity);
    logger.trace('Key: ' + key);
    return key;
}

/**
*  Build Hourly operator key.
*
* @param {object} jsonObj 
*/
const buildHourlyOperatorKey = (jsonObj) => {
    let key = concat(
        jsonObj.quantity, colon,
        jsonObj.planning.cycletime, colon,
        jsonObj.cycletime, colon);
    logger.trace('Key: ' + key);
    return key;
}

/**
 * Add Cycle definition from json Object to a operator object.
 * @param {object} jsonObj 
 * @param {object} operator 
 */
const addCycleDef = (jsonObj, operator) => {
    // if(!jsonObj.cycledef || !Array.isArray(jsonObj.cycledef)) {
    //     logger.info('Skipping as Cycle Definitions are not found.');
    //     return operator;
    // }
    // for (var i = 0; i < jsonObj.cycledef.length; i++) {
    //     const key = jsonObj.cycledef[i];
    //     const val = jsonObj[key];
    //     const newKey = `${key}_arr`;
    //     operator["$push"][newKey] = val;
    // }
    // logger.trace('FINAL: ', operator);
    return operator;
}

/**
 * Get Assets.
 */
const getAssets = () => {
    return assets;
}

/**
 * Set Assets.
 * 
 * @param {Object} assetData 
 */
const setAssets = (assetData) => {
    assets = assetData;
}

/**
 * Get Auth URL
 */
const getAuthURL = () => {
    const URL = `http://${host}/server/authenticate`;
    logger.trace(`getAuthURL: ${URL}`);
    return URL;
}

/**
 * 
 * @param {Object} payload 
 * @param {Object} headers 
 */
const getAuth = async (payload, headers) => {
    return await axios.post(getAuthURL(), payload, { headers })
        .catch((error) => {
            logger.error(`Exception while authenticating: ${JSON.stringify(error)}`);
        });
}

/**
 * Get Asset URL.
 */
const getAssetsURL = () => {
    const URL = `http://${host}:${port}/server/asset`;
    logger.trace(`getAssetsURL: ${URL}`);
    return URL;
}

/**
 * Get Assets.
 * 
 * @param {Object} headers 
 */
const getAsset = async (headers) => {
    return await axios.get(getAssetsURL(), { headers })
        .catch((error) => {
            logger.error(`Exception while getting assets: ${JSON.stringify(error)}`);
        });
}

/**
 * Sleep for certain period in milli seconds.
 * 
 * @param {number} timeInMillis 
 */
const sleep = async (timeInMillis) => {
    logger.trace(`Sleeping for ${timeInMillis} milliseconds.`);
    await setTimeout(() => { }, timeInMillis);
}

/**
 * Get Asset URL.
 */
const getMyDetailsURL = () => {
    const URL = `http://${host}:${port}/server/users/mydetails`;
    logger.trace(`getMyDetailsURL: ${URL}`);
    return URL;
}

const groupBy = (arr, key) => {
    let result = {};
    arr.forEach((obj) => {
        if (obj.hasOwnProperty(key)) {
            const val = obj[key];
            if (!result[val]) {
                result[val] = [];
            }
            obj.targetQty = Math.floor((obj.actm_sum / obj.sctm) * obj.cavity);
            result[val].push(obj);
        }
    });
    return result;
}

/**
 * Get Machine Operator Map.
 */
const getMachineOperatorMap = () => {
    return machineOperatorMap;
}

/**
 * Set Machine Operator Map.
 * 
 * @param {Object} assetData 
 */
const setMachineOperatorMap = (operatorData) => {
    if (operatorData.length) {
        operatorData.forEach((op) => {
            const key = `${op._id.siteId}_${op._id.machinename}`;
            machineOperatorMap.set(key, {
                operatorId: op.lastOperatorId,
                operatorName: op.lastOperatorName,
            });
        })
    } else {
        if (operatorData && operatorData.key && operatorData.value) {
            machineOperatorMap.set(operatorData.key, operatorData.value);
        }
    }
}

/**
 * Get Last Operator for each machine and site.
 */
const getLastOperatorDetails = (db) => {
    const collectionName = 'operatorlog';
    const collection = db.collection(collectionName);
    const aggregationQuery = [
        {
            $match: {
                signintime: { $exists: true }
            }
        },
        {
            $group: {
                _id: { machinename: '$machinename', siteId: '$siteId' },
                lastOperatorName: { $last: '$operatorname' },
                lastOperatorCode: { $last: '$operatorcode' },
                lastOperatorId: { $last: '$operatorid' }
            }
        }
    ];
    return new Promise((resolve, reject) => {
        collection.aggregate(aggregationQuery).toArray((err, docs) => {
            if (err) {
                logger.fatal("Error occured while fetching operator log details : " + JSON.stringify(err));
            } else {
                if (docs) {
                    setMachineOperatorMap(docs);
                }
            }
            resolve();
        });
    });
}


const roundOff = (value) => Math.round((value + Number.EPSILON) * 100) / 100;

module.exports = {
    MongoClient,
    bunyan,
    CUSTOMERWISE_BUSINESS_HOURS_AGGREGATION_QUERY,
    CUSTOMERWISE_SHIFT_BRACKET_QUERY,
    concat,
    handleASMRequest,
    publishSSEvent,
    drawLine,
    buildConditionKey,
    buildHourlyConditionKey,
    buildShiftWiseConditionKey,
    buildPlanWiseConditionKey,
    buildHourlyOperatorKey,
    addCycleDef,
    getAssets,
    setAssets,
    getAuthURL,
    getAuth,
    getAssetsURL,
    getAsset,
    getLastOperatorDetails,
    getMachineOperatorMap,
    setMachineOperatorMap,
    sleep,
    groupBy,
    handlerAlarmRequest,
    roundOff,
    getEmitter,
    authenticate,
    fillTemplate,
    sendEmail,
    sendSMS,
    NOTIFICAITON_TOPICS,
};
