
const config = require('../../../config/config.json');
const Aggregation = require('../../base/aggregation.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'consumer-downtime-hourly',
    level: config.logLevel
});

/**
 * Aggregation Implementation.
 */
class ConsumerDowntimeHourly extends Aggregation {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     * @param {object} dbDetails options required while connecting the DB.
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     * 
     * @async
     * @method
     */
    async initDB() {
        await super.initDB();
        logger.error('Consumer to Downtime hourly aggregation service flow initialised.');
        return 0;
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        try {
            logger.error('Received Downtime event.');
            logger.trace(`Downtime Data: ${JSON.stringify(message)}`);
            super.publish(message);
        } catch (error) {
            logger.error("Could not parse string to JSON object while processing." + error + JSON.stringify(error));
            return;
        }
    }
}

module.exports = ConsumerDowntimeHourly;