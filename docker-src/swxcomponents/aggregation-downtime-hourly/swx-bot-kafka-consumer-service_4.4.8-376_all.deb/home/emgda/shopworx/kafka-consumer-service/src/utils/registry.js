/** @constant {Object} registry registry for pre-decided implementations */
const registry = {
    CONSUMER: "consumer",
    AGGREGATE_CYCLETIME_HOURLY: "aggregate-cycletime-hourly",
    AGGREGATE_CYCLETIME_DAILY: "aggregate-cycletime-daily",
    AGGREGATE_CYCLETIME_PLAN: "aggregate-cycletime-plan",
    AGGREGATE_DOWNTIME_HOURLY: "aggregate-downtime-hourly",
    AGGREGATE_DOWNTIME_SHIFT: "aggregate-downtime-shift",
    AGGREGATE_DOWNTIME_DAILY: "aggregate-downtime-daily",
    AGGREGATE_DOWNTIME_PLAN: "aggregate-downtime-plan",
    AGGREGATE_REJECTION_HOURLY: "aggregate-rejection-hourly",
    AGGREGATE_REJECTION_SHIFT: "aggregate-rejection-shift",
    AGGREGATE_REJECTION_DAILY: "aggregate-rejection-daily",
    AGGREGATE_REJECTION_PLAN: "aggregate-rejection-plan",
    AGGREGATE_CYCLETIME_SHIFT: "aggregate-cycletime-shift",
    TRANSFORM_ASSET_STATE_HOURLY: "transform-asset-state-hourly",
    TRANSFORM_ASSET_STATE_SHIFT: "transform-asset-state-shift",
    TRANSFORM_ASSET_STATE_PLAN: "transform-asset-state-plan",
    MACHINEWISE_OEE_HOURLY: "machinewise-oee-hourly",
    MACHINEWISE_OEE_SHIFT: "machinewise-oee-shift",
    AGGREGATE_ENERGY_HOURLY: "aggregate-energy-hourly",
    AGGREGATE_ENERGY_SHIFT: "aggregate-energy-shift",
    AGGREGATE_LATEST_CYCLETIME: "aggregate-latest-cycletime",
    ALERT_DOWNTIME: "alert-downtime",
    ALERT_PROCESS: "alert-process",
    NOTIFICATION_SSE: "notification-sse",
    NOTIFICATION_EMAIL: "notification-email",
    NOTIFICATION_SMS: "notification-sms",
    AGGREGATE_PROCESS_HOURLY: "aggregate-process-hourly",
    AGGREGATE_PROCESS_SHIFT: "aggregate-process-shift"
}

/**
 * Get registry for pre-decided implementations
 */
const getRegistry = () => {
    return registry;
}

/**
 * exports
 */
module.exports = {
    getRegistry
};
