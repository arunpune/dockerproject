const config = require('../../../config/config.json');
const Transformation = require('../../base/transformation.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const { CompressionTypes } = require('kafkajs');

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'asset-state-plan',
    level: config.logLevel
});

/**
 * Aggregation Implementation.
 */
class TransformAssetStatePlan extends Transformation {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
     */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
        this.transformationAssetStatePlan = 'transformation-facts';
        this.type = "plan";
        this.aggregateCollection = "aggregateplan";
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     */
    async initDB() {
        await super.initDB();
        logger.error('Transformation Asset State Planwise service flow initialised.');
        return 0;
    }

    /**
     * Process a message.
     * 
     * @param {string} message 
     */
    async process(message) {
        let obj = {};
        try {
            obj = JSON.parse(message);
        } catch (error) {
            logger.error("Could not parse string to JSON object while processing." + error + JSON.stringify(error));
            return;
        }
        const data = obj.value || obj;
        logger.trace('Transformation Asset State Planwise service received data: ' + JSON.stringify(data));
        if(!data) {
            return;
        }
        /**
         * Get Process Parameter if any
         */
        const processDataCondition = this.getProcessDataCondition(data);
        const pd = await this.getProcessData(this.aggregateCollection, processDataCondition);
        const processData = pd.obj || {};
        /**
         * GET PERFORMANCE
         */
        const perfCondition = this.getPerfCondition(data);
        const perf = await this.getPerformance(this.aggregateCollection, data, perfCondition);
        if (typeof perf.num !== 'number') {
            logger.info("Perf value is not a number.");
            return;
        }
        if (perf.num < 0) {
            logger.info("Perf value is less than 0.");
            return;
        }
        const performance = perf.obj || {};
        performance.performance = perf.num;
        /**
         * GET QUALITY
         */
        const qualityCondition = this.getQualityCondition(data);
        const qual = await this.getQuality(this.aggregateCollection, performance, qualityCondition);
        if (typeof qual.num !== 'number') {
            logger.info("Quality value is less than 0.");
            return;
        }
        if (qual.num < 0) {
            logger.info("Quality value is less than 0.");
            return;
        }
        const quality = qual.obj || {};
        quality.quality = qual.num;
        const key = utility.buildConditionKey(data);
        const assetStateObj = Object.assign(data, performance, quality, processData);
        // adding more more keys
        assetStateObj.type = this.type;
        logger.info(`KEY: ${key}, PQ: [${assetStateObj.performance}, ${assetStateObj.quality}]`);
        this.publishOEE(JSON.stringify(assetStateObj));
    }

    /**
     * Get ProcessData.
     * 
     * @async
     * @param {object} aggregateCollection 
     * @param {object} condition 
     */
    async getProcessData(aggregateCollection, condition) {        
        const collection = this.db.collection(aggregateCollection);
        // run DB query using promise, resolve the value, on exception log the error, but return -1
        return new Promise((resolve, reject) => {
            logger.trace("getProcessData condition: " + JSON.stringify(condition));
            collection.findOne(condition, (err, document) => {
                logger.trace("Document identified while searching process data aggregation: " + JSON.stringify(document));
                if (err) {
                    logger.fatal("Error occured while finding process data record in aggregation collection : " + JSON.stringify(err));
                    resolve({"obj" : document});
                } else if (null === document) {
                    // this means that no process data aggregation record was found, so processData has to be 100% during that hour bracket.
                    logger.error("process data record not found in aggregation collection.");
                    resolve({"obj" : document});
                } else {
                    resolve({"obj" : document});
                }
            });
        });
    }

    /**
     * Get Performance.
     * 
     * @async
     * @param {object} jsonObj
     */
    async getPerformance(aggregateCollection, jsonObj, condition) {
        const collection = this.db.collection(aggregateCollection);
        // run DB query using promise, resolve the value, on exception log the error, but return -1
        return new Promise((resolve, reject) => {
            logger.trace("getPerformance condition: " + JSON.stringify(condition));
            collection.findOne(condition, (err, document) => {
                logger.trace("Document identified while searching production aggregation: " + JSON.stringify(document));
                if (err) {
                    logger.fatal("Error occured while finding production record in aggregation collection : " + JSON.stringify(err));
                    resolve(this.buildObj(-1, document));
                } else if (null === document) {
                    // this means that no rejection aggregation record was found, so quality has to be 100% during that hour bracket.
                    logger.error("production record not found in aggregation collection.");
                    resolve(this.buildObj(0, document));
                } else {
                    const targetQty = Math.floor((document.actm_sum / document.sctm) * document.cavity);
                    if(0 === targetQty) {
                        // this means the time window for that hour might have just started. so Performance is assumed 100% here.
                        resolve(this.buildObj(100, document));
                    }
                    logger.trace("document = " + JSON.stringify(document));
                    const actualQty = document.qty;
                    /**
                     * remainingDuration = ((planned qty - produced qty) * standard cycletime) / active cavity;
                     */
                    const remainingDuration = Math.floor(((document.plannedquantity - document.qty) * document.sctm) / document.cavity);
                    document.remainingDuration = remainingDuration;
                    const performance = utility.roundOff((actualQty / targetQty) * 100);
                    logger.trace(`ACTUAL QTY: ${actualQty}, TARGET QTY: ${targetQty}, PERF: ${performance}, REMAINING DURATION: ${remainingDuration}`);
                    resolve(this.buildObj(performance, document));
                }
            });
        });
    }

    /**
     * Get Quality.
     * 
     * @async
     * @param {object} jsonObj 
     */
    async getQuality(aggregateCollection, jsonObj, condition) {        
        const collection = this.db.collection(aggregateCollection);
        return new Promise((resolve, reject) => {
            logger.trace("getQuality condition: " + JSON.stringify(condition));
            if(!jsonObj.hasOwnProperty('qty')) {
                // this mean no production happened, hence quality must be zero.
                resolve(this.buildObj(0, {}));
            }
            const {rqty} = collection.aggregate(this.getAggregationPipeline(jsonObj));
            logger.trace("Document identified while searching rejection aggregation: " + JSON.stringify(jsonObj));
            if (!rqty) {
                logger.fatal(`rejected qty is either undefined or zero, value: ${rqty}`);
                resolve(this.buildObj(100, jsonObj));
            } else {
                const actualQuantity = jsonObj.qty;
                logger.trace('Actual Quantity: ' + actualQuantity);
                const rejectedQuantity = rqty;
                logger.trace('Rejected Quantity: ' + rejectedQuantity);
                const quality = utility.roundOff(((actualQuantity - rejectedQuantity) / actualQuantity) * 100);
                logger.trace("Quality = " + quality);
                resolve(this.buildObj(quality, jsonObj));
            }
        });
    }
    

    /**
     * Get process data condition.
     * 
     * @param {object} jsonObj 
     */
    getProcessDataCondition(jsonObj) {
        return {
            customerId: jsonObj.customerId,
            siteId: jsonObj.siteId,
            elementName: jsonObj.elementName,
            machinename: jsonObj.machinename,
            planid: jsonObj.planid,
            partname: jsonObj.partname,
            day: jsonObj.day,
            hour: jsonObj.hour,
            month: jsonObj.month,
            year: jsonObj.year,
            week: jsonObj.week
        };
    }

    /**
     * Get Performance condition.
     * 
     * @param {object} jsonObj 
     */
    getPerfCondition(jsonObj) {
        return {
            customerId: jsonObj.customerId,
            siteId: jsonObj.siteId,
            elementName: "cycletime",
            machinename: jsonObj.machinename,
            planid: jsonObj.planid,
            partname: jsonObj.partname
        };
    }

    /**
     * Get Quality condition.
     * 
     * @param {object} jsonObj 
     */
    getQualityCondition(jsonObj) {
        return {
            customerId: jsonObj.customerId,
            siteId: jsonObj.siteId,
            elementName: "rejection",
            machinename: jsonObj.machinename,
            planid: jsonObj.planid,
            partname: jsonObj.partname
        };
    }

    /**
     * Publish message that will also include Performance parameter.
     * 
     * @param {string} message 
     */
    publishOEE(message) {
        // do processing [like delegating message to promise].
        const payload = { topic: this.transformationAssetStatePlan, compression: CompressionTypes.None, messages: [{ key: null, value: message }] };
        logger.error("Published Message.");
        logger.info("Published Asset State Plan Message: " + JSON.stringify(payload));
        this.producer
            .send(payload)
            .catch(error => { logger.error(error) });
    }

    getAggregationPipeline(jsonObj) {
        return [
            { "$match" : this.getQualityCondition(jsonObj) },
            { "$group": { "_id": null, "rqty": { $sum: "$quantity" } } }
        ]
    }
}

module.exports = TransformAssetStatePlan;