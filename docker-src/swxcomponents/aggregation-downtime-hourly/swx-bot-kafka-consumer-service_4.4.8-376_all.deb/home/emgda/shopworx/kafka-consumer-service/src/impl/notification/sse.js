const express = require('express');
const config = require('../../../config/config.json');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const Consumer = require('../../base/consumer')
const logger = bunyan.createLogger({
    name: 'notification-sse',
    level: config.logLevel
});
const server = express();

class NotificationSse extends Consumer {

    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel);
        let route = `/${config.sse.endpoint}`;
        logger.error(`Setting route: ${route}`);
        server.get(route, utility.handlerAlarmRequest);
        server.listen(config.sse.port, () => {
            logger.error(`SSEvent app is now up and running on port ${config.sse.port}!`);
        });
    }

    async process(message) {
        try {
            message = JSON.parse(message);
            let obj = {
                meta: message.meta,
                type: message.type,
                message: message.notification.template
            };

            message.notification.users.map((user) => {
                obj.userid = user.id;
                obj.deliveryAddress = user.deliveryAddress;
                const str = JSON.stringify(obj);
                super.publishSSEvent(str);
            })
        } catch (error) {
            logger.error("Error while processing kafka message. " + error + JSON.stringify(error));
            return;
        }
    }

}

module.exports = NotificationSse;