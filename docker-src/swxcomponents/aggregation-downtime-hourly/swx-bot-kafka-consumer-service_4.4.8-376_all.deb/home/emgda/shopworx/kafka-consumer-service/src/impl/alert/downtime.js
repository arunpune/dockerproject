const config = require('../../../config/config.json');
const configRule = require('../../../config/rule.json');
const messagetemplates = require('../../../config/template.json');
const Alert = require('../../base/alert.js');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const { Engine } = require("json-rules-engine");
const { json } = require('express/lib/response');
const engine = new Engine();
let timerList = {};

const NOTIFICATION_TOPIC = 'notification-sse';
const EMAIL_TOPIC = 'notification-email';

const logger = bunyan.createLogger({
    name: 'alert-downtime',
    level: config.logLevel
});

const { downtimetemplates } = messagetemplates.templates.pushnotification;

const { pushnotification, emailnotification } = messagetemplates.templates;

class AlertDowntime extends Alert {

    /**
     * A constructor
     * 
     * @param {string} brokerList The List of the brokers in the kafka Cluster 
     * @param {string} clientId The Client ID assiciated with consumer
     * @param {string} groupId The name of the group to which a topic shall belong
     * @param {string} topicName The name of the topic
     * @param {boolean} isReadFromBeginning Whether to read from the beginning of the Topic
     * @param {boolean} kafkaLogLevel   NOTHING = 0,ERROR = 1,WARN = 2,INFO = 4,DEBUG = 5
    */
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails);
        this.collectionName = 'downtime';
        // this.elementName = 'latestdowntime';
    }

    async initDB() {
        try {
            await super.initDB();
            logger.error('Alert to get latest downtime service flow initialised.');
            return 0;
        } catch (error) {
            logger.error("Error while connecting database. error :" + JSON.stringify(error));
            return;
        }
    }

    initRuleEngine() {
        try {
            configRule.rules.map((rule, index) => {
                let ruleobject = {};
                ruleobject.conditions = rule.ruleCondition;
                ruleobject.event = {
                    type: rule.type,
                    params: {
                        ruleid: rule.id,
                        name: rule.name,
                        notification: rule.notification,
                        type: rule.type,
                        priority: rule.priority
                    }
                };
                configRule.rules[index] = ruleobject;
                engine.addRule(ruleobject);
            })
        } catch (error) {
            logger.error("Invalid rules, please check rules configuration. " + error + JSON.stringify(error));
            return;
        }
    }

    async getInProgressDowntime() {
        try {
            const collectionName = 'downtime';
            const collection = this.db.collection(collectionName);
            const aggregationQuery = [
                {
                    $match: {
                        status: 'inProgress'
                    }
                },
                {
                    $group: {
                        _id: { machinename: '$machinename', siteId: '$siteId' },
                        downtimestart: { $last: '$downtimestart' },
                        actualdowntimestart: { $last: '$actualdowntimestart' },
                        status: { $last: '$status' },
                        customerId: { $last: '$customerId' },
                        siteId: { $last: '$siteId' },
                        machinename: { $last: '$machinename' },
                        assetid: { $last: '$assetid' },
                    }
                }
            ];

            await collection.aggregate(aggregationQuery).toArray((err, docs) => {
                if (err) {
                    logger.fatal("Error occured while fetching operator log details : " + JSON.stringify(err));
                } else {
                    if (docs) {
                        for (let i = 0; i < docs.length; i++) {
                            this.process(JSON.stringify(docs[i]));
                        }
                    }
                }
            });
        } catch (error) {
            logger.error("Error while getting inProgress downtime. " + error + JSON.stringify(error));
            return;
        }
    }

    async initAssets() {
        try {
            this.initRuleEngine();
            await this.getInProgressDowntime();
        } catch (error) {
            logger.error("Error while initializing assets. " + error + JSON.stringify(error));
            return;
        }
    }

    async process(message) {
        try {
            message = JSON.parse(message);
            let obj = {};
            configRule.rules.map((rule) => {
                let key = message.customerId + "_" + message.siteId + "_" + message.machinename + "_" + rule.event.params.ruleid + "_" + message.actualdowntimestart;
                //fetch all downtime operators from rule
                for (let attribute in rule.conditions) {
                    obj[attribute] = [];
                    let conditionObj = {};
                    rule.conditions[attribute].map((condition) => {
                        if (condition.fact == "downtime") {
                            conditionObj[condition.operator] = condition.value;
                        }
                    })
                    obj[attribute].push(conditionObj);
                }
                // to be added - even if the downtime fact is not available, it should check for rule conditions

                //check operator and traverse the rule to check for truthy conditions
                for (let attribute in obj) {
                    let operators = Object.keys(obj[attribute][0]);

                    if (attribute == "all") {
                        if ((operators.includes("greaterThan")) && (operators.includes("lessThan"))) {
                            this.checkConditions(message, 1, obj[attribute][0], key)
                        } else if ((operators.includes("greaterThanInclusive")) && (operators.includes("lessThan"))) {
                            this.checkConditions(message, 2, obj[attribute][0], key)
                        } else if ((operators.includes("greaterThanInclusive")) && (operators.includes("lessThanInclusive"))) {
                            this.checkConditions(message, 3, obj[attribute][0], key)
                        } else if ((operators.includes("greaterThan")) && (operators.includes("lessThanInclusive"))) {
                            this.checkConditions(message, 4, obj[attribute][0], key)
                        } else if (operators.includes("greaterThan")) {
                            this.checkConditions(message, 5, obj[attribute][0], key)
                        } else if (operators.includes("greaterThanInclusive")) {
                            this.checkConditions(message, 6, obj[attribute][0], key)
                        } else if (operators.includes("lessThan")) {
                            this.checkConditions(message, 7, obj[attribute][0], key)
                        } else if (operators.includes("lessThanInclusive")) {
                            this.checkConditions(message, 8, obj[attribute][0], key)
                        }

                    } else if (attribute == "any") {
                        if ((operators.includes("greaterThan")) && (operators.includes("lessThan"))) {
                            this.checkConditions(message, 9, obj[attribute][0], key)
                        } else if ((operators.includes("greaterThanInclusive")) && (operators.includes("lessThan"))) {
                            this.checkConditions(message, 10, obj[attribute][0], key)
                        } else if ((operators.includes("greaterThanInclusive")) && (operators.includes("lessThanInclusive"))) {
                            this.checkConditions(message, 11, obj[attribute][0], key)
                        } else if ((operators.includes("greaterThan")) && (operators.includes("lessThanInclusive"))) {
                            this.checkConditions(message, 12, obj[attribute][0], key)
                        } else if (operators.includes("greaterThan")) {
                            this.checkConditions(message, 5, obj[attribute][0], key)
                        } else if (operators.includes("greaterThanInclusive")) {
                            this.checkConditions(message, 6, obj[attribute][0], key)
                        } else if (operators.includes("lessThan")) {
                            this.checkConditions(message, 7, obj[attribute][0], key)
                        } else if (operators.includes("lessThanInclusive")) {
                            this.checkConditions(message, 8, obj[attribute][0], key)
                        }
                    }
                }
            })
        } catch (error) {
            logger.error("Error while processing kafka message. " + error + JSON.stringify(error));
            return;
        }
    }

    async checkConditions(message, caseNumber, obj, key) {
        try {
            switch (caseNumber) {
                case 1:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff > obj.greaterThan && diff < obj.lessThan) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                if (diff < obj.greaterThan) {
                                    let timeInterval = obj.greaterThan - diff;
                                    message.downtime = obj.greaterThan + 1;
                                    timerList[key] = setTimeout(() => {
                                        this.ruleEngine(message);
                                    }, timeInterval);
                                }
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 2:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff >= obj.greaterThanInclusive && diff < obj.lessThan) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                if (diff < obj.greaterThanInclusive) {
                                    let timeInterval = obj.greaterThanInclusive - diff;
                                    message.downtime = obj.greaterThanInclusive + 1;
                                    timerList[key] = setTimeout(() => {
                                        this.ruleEngine(message);
                                    }, timeInterval);
                                }
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 3:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff >= obj.greaterThanInclusive && diff <= obj.lessThanInclusive) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                if (diff < obj.greaterThanInclusive) {
                                    let timeInterval = obj.greaterThanInclusive - diff;
                                    message.downtime = obj.greaterThanInclusive + 1;
                                    timerList[key] = setTimeout(() => {
                                        this.ruleEngine(message);
                                    }, timeInterval);
                                }
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 4:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff > obj.greaterThan && diff <= obj.lessThanInclusive) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                if (diff < obj.greaterThan) {
                                    let timeInterval = obj.greaterThan - diff;
                                    message.downtime = obj.greaterThan + 1;
                                    timerList[key] = setTimeout(() => {
                                        this.ruleEngine(message);
                                    }, timeInterval);
                                }
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 5:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff > obj.greaterThan) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                let timeInterval = obj.greaterThan - diff;
                                message.downtime = obj.greaterThan + 1;
                                timerList[key] = setTimeout(() => {
                                    this.ruleEngine(message);
                                }, timeInterval);
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 6:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff >= obj.greaterThanInclusive) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                let timeInterval = obj.greaterThanInclusive - diff;
                                message.downtime = obj.greaterThanInclusive + 1;
                                timerList[key] = setTimeout(() => {
                                    this.ruleEngine(message);
                                }, timeInterval);
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 7:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff < obj.lessThan) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 8:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff <= obj.lessThanInclusive) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 9:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff > obj.greaterThan || diff < obj.lessThan) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                if (diff < obj.greaterThan) {
                                    let timeInterval = obj.greaterThan - diff;
                                    message.downtime = obj.greaterThan + 1;
                                    timerList[key] = setTimeout(() => {
                                        this.ruleEngine(message);
                                    }, timeInterval);
                                }
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 10:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff >= obj.greaterThanInclusive || diff < obj.lessThan) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                if (diff < obj.greaterThanInclusive) {
                                    let timeInterval = obj.greaterThanInclusive - diff;
                                    message.downtime = obj.greaterThanInclusive + 1;
                                    timerList[key] = setTimeout(() => {
                                        this.ruleEngine(message);
                                    }, timeInterval);
                                }
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 11:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff >= obj.greaterThanInclusive || diff <= obj.lessThanInclusive) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                if (diff < obj.greaterThanInclusive) {
                                    let timeInterval = obj.greaterThanInclusive - diff;
                                    message.downtime = obj.greaterThanInclusive + 1;
                                    timerList[key] = setTimeout(() => {
                                        this.ruleEngine(message);
                                    }, timeInterval);
                                }
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                case 12:
                    if (message.actualdowntimestart && message.status == "inProgress") {
                        let date = new Date().getTime();
                        let diff = date - message.actualdowntimestart;
                        if (diff) {
                            if (diff > obj.greaterThan || diff <= obj.lessThanInclusive) {
                                message.downtime = diff;
                                await this.ruleEngine(message);
                            } else {
                                if (diff < obj.greaterThan) {
                                    let timeInterval = obj.greaterThan - diff;
                                    message.downtime = obj.greaterThan + 1;
                                    timerList[key] = setTimeout(() => {
                                        this.ruleEngine(message);
                                    }, timeInterval);
                                }
                            }
                        }
                    } else if (message.status == "complete") {
                        //complete status alert
                        await this.updateCompleteDowntime(message, key);
                    }
                    break;
                default:
                    logger.fatal('No relevant switch case Implemented.');
            }
        } catch (error) {
            logger.error("Error while validating rule conditions. " + error + JSON.stringify(error));
            return;
        }
    }

    async ruleEngine(message) {
        try {
            engine.run(message).then((response) => {
                if (response.results.length) {

                    response.results.map((res, i) => {
                        let result;
                        if (response.results[i]["conditions"]["all"]) {
                            result = response.results[i]["conditions"]["all"];
                        } else if (response.results[i]["conditions"]["any"]) {
                            result = response.results[i]["conditions"]["any"];
                        }
                        this.updateSuccessDowntime(message, response.results[i].event, result)
                    })

                } else if (response.failureResults) {
                    logger.error(`Downtime for machine name  ${message.machinename} does not exceeded.`);
                }
            }, (error) => {
                logger.error("error ", error);
            });

        } catch (error) {
            logger.error("Error while processing rule engine. " + error + JSON.stringify(error));
            return;
        }
    }

    async updateSuccessDowntime(message, event, result) {
        try {
            let collectionName = 'alarm';
            const collection = this.db.collection(collectionName);
            let query = {
                key: message.customerId + "_" + message.siteId + "_" + message.machinename + "_" + event.params.ruleid + "_" + message.actualdowntimestart
            }

            let duration;
            let onTime = new Date();

            if (result.length) {
                result.map((res, i) => {
                    if (res.fact === "downtime") {
                        duration = res.factResult;
                    }
                })
            }

            message.onTime = onTime;
            message.duration = duration;

            let options = { upsert: true, returnOriginal: false };

            let downtimemessage = '';

            event.params.notification.map((mechanism) => {
                if (mechanism.deliveryMechanism == "PUSH") {
                    downtimemessage = utility.fillTemplate(pushnotification.downtimetemplates.downtime, message);
                    mechanism.template = downtimemessage;
                } else if (mechanism.deliveryMechanism == "EMAIL") {
                    downtimemessage = emailnotification.downtimetemplates.downtime;
                    downtimemessage.body = utility.fillTemplate(downtimemessage.body, message);
                    downtimemessage.subject = utility.fillTemplate(downtimemessage.subject, message);
                    mechanism.template = downtimemessage;
                } else if (mechanism.deliveryMechanism == "SMS") {
                    downtimemessage = utility.fillTemplate(pushnotification.downtimetemplates.downtime, message);
                    mechanism.template = downtimemessage;
                }
            })
            let update = {
                $set: {
                    "type": event.params.type,
                    "ruleCondition": result,
                    "meta": {
                        "machinename": message.machinename
                    },
                    "ruleid": event.params.ruleid,
                    "name": event.params.name,

                    "offTime": "",
                    "priority": event.params.priority,
                    "customerId": message.customerId,
                    "siteId": message.siteId,
                    "status": "inProgress",
                    "notification": event.params.notification
                },
                $setOnInsert: {
                    "onTime": onTime
                }
            }
            return new Promise((resolve, reject) => {
                collection.findOneAndUpdate(query, update, options, (err, document) => {
                    if (err) {
                        logger.fatal("Error occured while upsert to aggregation collection : " + JSON.stringify(err));
                    } else if (!document || (Object.keys(document).length === 0 && document.constructor === Object)) {
                        logger.error('Seems like the record is not getting updated. Kindly check Collection.');
                    } else if (document.value === null) {
                        logger.error('Seems like the record is inserted at Backend.');
                    }
                    else {
                        if (document.lastErrorObject["updatedExisting"] === false) {
                            logger.error(`Alert! Rule id "${document.value.ruleid}" for rule name "${document.value.name}" exceeded!`);
                            logger.error("Successfully inserted or updated document.");
                            let str = {};
                            if (document.value) {
                                document.value.notification.map((mechanism) => {
                                    let obj = {
                                        meta: document.value.meta,
                                        type: document.value.type,
                                        notification: mechanism
                                    };

                                    obj = JSON.stringify(obj);
                                    
                                    super.publish(obj, utility.NOTIFICAITON_TOPICS[mechanism.deliveryMechanism]);

                                    // if (mechanism.deliveryMechanism === "PUSH") {
                                    //     let obj = {
                                    //         meta: document.value.meta,
                                    //         type: document.value.type,
                                    //         notification: mechanism
                                    //     };

                                    //     obj = JSON.stringify(obj);
                                    //     super.publish(obj, TOPICS[mechanism.deliveryMechanism]);
                                    // }
                                    // if (mechanism.deliveryMechanism === "EMAIL") {
                                    //     let obj = {
                                    //         meta: document.value.meta,
                                    //         type: document.value.type,
                                    //         notification: mechanism
                                    //     };
                                    //     obj = JSON.stringify(obj);

                                    //     super.publish(obj, TOPICS[mechanism.deliveryMechanism]);
                                    // }
                                })
                            }
                        } else {
                            logger.error(`Same Alert! Rule id "${document.value.ruleid}" for rule name "${document.value.name}" exceeded again!`)
                        }

                    }
                    resolve();
                });
            });
        } catch (error) {
            logger.error("Error while saving in progress alarm. " + error + JSON.stringify(error));
            return;
        }
    }

    async updateCompleteDowntime(message, key) {
        try {
            let collectionName = 'alarm';
            const collection = this.db.collection(collectionName);

            clearTimeout(timerList[key]);
            let query = {
                key
            }
            let update = {
                "$set": {
                    "status": "complete",
                    "offTime": message.downtimeend
                }
            }
            const options = { returnNewDocument: true };
            collection.findOneAndUpdate(query, update, options)
                .then((updatedDocument) => {
                    if (updatedDocument.value) {
                        logger.error("Complete alarm for machine : " + message.machinename);
                    } else {
                        logger.error("Alert rule conditions does not met");
                        logger.error("No document matches the provided query.");

                    }
                })
                .catch((err) => logger.error(`Failed to find and update document: ${err}`));
        } catch (error) {
            logger.error("Error while saving complete alarm. " + error + JSON.stringify(error));
            return;
        }
    }
}

module.exports = AlertDowntime;