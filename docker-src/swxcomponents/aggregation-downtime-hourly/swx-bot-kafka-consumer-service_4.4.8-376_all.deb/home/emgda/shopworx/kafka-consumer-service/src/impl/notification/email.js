const config = require('../../../config/config.json');
const utility = require('../../utils/utility.js');
const bunyan = utility.bunyan;
const Consumer = require('../../base/consumer');
const HTTP_SUCCESS_CODE = 200;
let HEADER = {};

/**
 * Create Logger instance
 */
const logger = bunyan.createLogger({
    name: 'notification-email',
    level: config.logLevel
});

class NotificationEmail extends Consumer {
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel);
    }

    async initAssets() {
        try {
            const credentials = config.client.credentials;
            let response = await utility.getAuth(credentials, { 'loginType': 'INFINITY' });
            if (!response || !response.status || HTTP_SUCCESS_CODE !== response.status) {
                logger.error(`Error in authentication to server ${JSON.stringify(response.data)}`);
                this.retryInitAsset();
            }
            HEADER.sessionId = response.data.sessionId;
            logger.trace('Successfully authenticate to server.');
        } catch (error) {
            logger.error("Error while initializing assets. error: " + JSON.stringify(error));
            return;
        }

    }

    async retryInitAsset() {
        try {
            await utility.sleep(5000);
            await this.initAssets();
            return;
        } catch (error) {
            logger.error("Error while retying initialize assets. error: " + JSON.stringify(error));
            return;
        }
    }

    async process(message) {
        try {
            message = JSON.parse(message);
            message.notification.users.map((user) => {
                let obj = {
                    to: user.deliveryAddress,
                    subject: message.notification.template.subject,
                    messageCode: message.notification.template.body
                }
                this.sendEmail(obj, HEADER)
            })
        } catch (error) {
            logger.error("Error while processing kafka message. error: " + JSON.stringify(error));
            return;
        }
    }

    async sendEmail(message, header) {
        try {
            let response = await utility.sendEmail(message, header);
            if (!response || !response.status || HTTP_SUCCESS_CODE !== response.status || !response.data.success) {
                logger.error(`Error while sending email ${JSON.stringify(response.data)}`);
                this.retryInitAsset();
                this.sendEmail(message, HEADER)

            } else {
                logger.error(`Email sent successfully to ${message.to}`)
            }
        } catch (error) {
            logger.error("Error while sending email. error: " + JSON.stringify(error));
            return;
        }
    }
}

module.exports = NotificationEmail;