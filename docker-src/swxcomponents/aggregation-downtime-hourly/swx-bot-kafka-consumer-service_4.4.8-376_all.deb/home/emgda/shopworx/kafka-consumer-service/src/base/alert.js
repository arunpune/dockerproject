const config = require('../../config/config.json');
const Consumer = require('./consumer.js');
const utility = require('../utils/utility.js');
const MongoClient = utility.MongoClient;
const bunyan = utility.bunyan;

const logger = bunyan.createLogger({
    name: 'alert-service',
    level: config.logLevel
});

class Alert extends Consumer {
    constructor(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel, dbDetails) {
        super(brokerList, clientId, groupId, topicName, isReadFromBeginning, maxBytesPerPartition, kafkaLogLevel);
        this.dbDetails = dbDetails;
        this.mongoURL = this.dbDetails.url;
        this.mongoDBName = this.dbDetails.dbName;
        this.dbOptions = this.dbDetails.options;
         /**
         * create in-memory conditions cache
         * checkperiod is set to 5 minutes and not configurable.
         **/
          let expiry = Math.floor(config.cacheExpiryInHours * 3600);
          let nCacheObj = { stdTTL: expiry, useClones: false };
          logger.error('Cache Expiry: ' + JSON.stringify(nCacheObj));
        
    }

    /**
     * Initialise the mongoDB for CRUD operations.
     * 
    */
    async initDB() {
        utility.drawLine();
        logger.error('Initialising DB');
        utility.drawLine();
        let URL = `${this.mongoURL}/${this.mongoDBName}`;
        let client = await MongoClient
            .connect(URL, this.dbOptions)
            .catch((error) => {
                logger.error(`Error while connecting to Mongo URL: ${URL}  : ${error}`);
                utility.drawLine();
            });
        if (!client) {
            process.exit(1);
        }
        // set db object as instance variable for greater performance.
        this.db = client.db(this.mongoDBName);
        logger.error(`Connected to Mongo DB ${URL}`);
        utility.drawLine();
        return true;
    }


}

module.exports = Alert;