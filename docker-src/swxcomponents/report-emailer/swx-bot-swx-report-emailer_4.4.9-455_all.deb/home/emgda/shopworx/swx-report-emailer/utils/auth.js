const nodePackage = require('../service/nodepackage.service');
const NodePackage = nodePackage.NodePackage;
const apiService = require('../service/api.service.js').ApiService;
const authService = require('../service/auth.service.js').AuthService;
const bunyan = NodePackage.bunyan;
const EventEmitter = NodePackage.EventEmitter;
const emitter = new EventEmitter.EventEmitter();
module.exports.auth = auth;
module.exports.emitter = emitter;

function auth(config, utility) {
    const credential = config.credential;
    const defaults = config.defaults;
    const requestTimeout = defaults.requestTimeout || 40;
    const retryServer = defaults.retry || 10;
    apiService.setTimeout(requestTimeout);
    // set loginType in axios header 
    apiService.setDefaultHeader(config.loginType);
    const log = bunyan.createLogger({ name: `auth`, level: config.log.level || 20 });
    return {
        name: `authentication`,
        onStartup: false,
        authResponse: {},
        /**
         * This method logged in to server using credentials configured in config file
        */
        async getAuthentication(isReportError = false) {
            try {
                const payload = {
                    identifier: credential.identifier,
                    password: credential.password
                };
                // let baseURL = `${config.server.protocol}://${config.server.host}:${config.server.port}`;
                const response = await authService.authenticate(payload);
                const { status, data } = response;
                if (status === utility.HTTP_STATUS_CODE.SUCCESS && data) {
                    apiService.setHeader(data.sessionId);
                    if (!this.onStartup) {
                        this.onStartup = true;
                        emitter.emit('init', data.sessionId);
                        // return data.sessionId;
                    } else if (isReportError) {
                        emitter.emit('report', data.sessionId);
                    } else {

                    }
                } else {
                    // retry for authentication
                    log.error(`Error in authentication to server ${JSON.stringify(response.data)}`);
                    await new Promise(resolve => setTimeout(resolve, retryServer * 1000));
                    await this.getAuthentication();
                }
            } catch (ex) {
                log.error(`Exception in authentication ${ex}`);
                await new Promise(resolve => setTimeout(resolve, retryServer * 1000));
                await this.getAuthentication();
            }
        },
    }
}