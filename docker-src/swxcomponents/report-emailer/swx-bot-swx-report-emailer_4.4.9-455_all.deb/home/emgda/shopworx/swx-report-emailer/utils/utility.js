const nodePackage = require('../service/nodepackage.service');
const NodePackage = nodePackage.NodePackage;
const bunyan = NodePackage.bunyan;
const EventEmitter = NodePackage.EventEmitter;
let emitter = new EventEmitter.EventEmitter();

let CONFIG;
const log = bunyan.createLogger({ name: 'utility', level: 20 })
/** @constant {Object} */

/** @constant {Object} */
const HTTP_STATUS_CODE = {
    SUCCESS: 200,
    ACCEPTED: 202,
    BAD_REQUEST: 406,
    NOT_ACCEPTABLE: 406,
    INTERNAL_SERVER_ERROR: 500
}
let requestTimeout = {
    timeout: 45 * 1000
}

/**
 * Checks if give configuration parameter exists with given data types. If no then exit node js service 
 * pointing deficiency in perticular parameter.
 * 
 * @param {string} configParam 
 * @param {string} dataType 
 */
const checkIfExists = (configParam, configParamString, dataType) => {
    // check if configuration parameter exists in configuration file.
    if (typeof configParam != 'boolean' && !configParam) {
        log.fatal("Configuration parameter is invalid OR absent: " + configParamString);
        process.exit(1);
    }
    // check if configuration parameter has valid data type.
    if (typeof configParam != dataType) {
        log.fatal("Data type for configuration parameter '" + configParamString + "' must be: " + dataType);
        process.exit(1);
    }
}

/**
 * validate the configuration parameter is valid with given conditions
 * 
 */
const validateConfigfileParameters = () => {

    log.info('Validating Configuration file.');

    checkIfExists(CONFIG.server, "CONFIG.server", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.server.protocol, "CONFIG.server.protocol", DATA_TYPE.STRING);
    checkIfExists(CONFIG.server.host, "CONFIG.server.host", DATA_TYPE.STRING);
    checkIfExists(CONFIG.server.port, "CONFIG.server.port", DATA_TYPE.NUMBER);
    checkIfExists(CONFIG.socketio, "CONFIG.socketio", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.socketio.host, "CONFIG.socketio.host", DATA_TYPE.STRING);
    checkIfExists(CONFIG.socketio.port, "CONFIG.socketio.port", DATA_TYPE.NUMBER);
    checkIfExists(CONFIG.credential, "CONFIG.credential", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.credential.password, "CONFIG.credential.password", DATA_TYPE.STRING);
    checkIfExists(CONFIG.credential.identifier, "CONFIG.credential.identifier", DATA_TYPE.STRING);

    checkIfExists(CONFIG.logger, "CONFIG.logger", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.logger.loglevel, "CONFIG.logger.loglevel", DATA_TYPE.NUMBER);

    checkIfExists(CONFIG.defaults, "CONFIG.defaults", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.defaults.retry, "CONFIG.defaults.retry", DATA_TYPE.NUMBER);

    checkIfExists(CONFIG.status, "CONFIG.status", DATA_TYPE.OBJECT);
    checkIfExists(CONFIG.status.notstarted, "CONFIG.status.notstarted", DATA_TYPE.STRING);
    checkIfExists(CONFIG.status.inprogress, "CONFIG.status.inprogress", DATA_TYPE.STRING);
    checkIfExists(CONFIG.status.complete, "CONFIG.status.complete", DATA_TYPE.STRING);
    checkIfExists(CONFIG.customerid, "CONFIG.customerid", DATA_TYPE.NUMBER);
    checkIfExists(CONFIG.userid, "CONFIG.userid", DATA_TYPE.NUMBER);

    log.info('Configuration file successfully validated.');

};


/**
 * Throw Error.
 * 
 * @param {object} reply 
 * @param {object} err 
 */
const throwError = (reply, err) => {
    reply.code(500).send({ message: err });
}

const checkSessionExpired = (data) => {
    if (data && data.errors && (data.errors.errorCode === 'INVALID_SESSION' || data.errors.errorCode === 'SESSION_ID_NULL')) {
        log.error(`Session Id expired ${JSON.stringify(data.errors)}`);
        emitter.emit('sessionExpired');
        return true;
    }
}



module.exports = {
    HTTP_STATUS_CODE,
    requestTimeout,
    validateConfigfileParameters,
    throwError,
    checkSessionExpired,
    emitter,
};