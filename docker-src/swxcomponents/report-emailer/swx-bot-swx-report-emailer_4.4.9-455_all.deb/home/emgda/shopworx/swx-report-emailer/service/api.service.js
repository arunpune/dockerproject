const nodePackage = require('./nodepackage.service');
const NodePackage = nodePackage.NodePackage;
const axios = NodePackage.axios;
const config = require('../config/config');
const server = config.server;
class ApiService {
  constructor() {
    // this.instance = axios.create();
    this.instance = axios.create({
      baseURL: `${server.protocol}://${server.host}:${server.port}`,
    });
  }

  setTimeout(timeout) {
    this.instance.defaults.timeout = (timeout || 5) * 1000
  }

  setDefaultHeader(loginType) {
    this.instance.defaults.headers.common.loginType = loginType;
  }
  setHeader(session) {
    this.instance.defaults.headers.common.sessionId = session;
    this.instance.defaults.headers.cookie = `JSESSIONID=${session}; sessionId=${session}`;
  }

  removeHeader() {
    this.instance.defaults.headers.common = {}
  }

  request(method, url, data = {}, config = {}) {
    return this.instance({
      method,
      url,
      data,
      config,
    });
  }

  get(url, config = {}) {
    return this.request('GET', url, {}, config);
  }

  post(url, data, config = {}) {
    return this.request('POST', url, data, config);
  }

  put(baseURL, url, data, config = {}) {
    return this.request(baseURL, 'PUT', url, data, config);
  }

  patch(baseURL, url, data, config = {}) {
    return this.request(baseURL, 'PATCH', url, data, config);
  }

  delete(baseURL, url, config = {}) {
    return this.request(baseURL, 'DELETE', url, {}, config);
  }
}

module.exports.ApiService = new ApiService();