const apiService = require('./api.service');
const ApiService = apiService.ApiService;

class ElementService {
  constructor() {
    this.request = ApiService;
  }

  getElementRecords(elementName, query, config) {
    let url = `/server/elements/${elementName}/records`;
    if (query) {
      url += `?${query}`
    }
    return this.request.get(`${url}`);
  }

  getUserDetails(config) {
    let url = `/server/users/mydetails`;
    return this.request.get(`${url}`);
  }

  updateElementRecordByQuery(elementName, data, query) {
    return this.request.put(`/server/elements/${elementName}/records?query=${query}`, data);
  }

}

module.exports.ElementService = new ElementService();
