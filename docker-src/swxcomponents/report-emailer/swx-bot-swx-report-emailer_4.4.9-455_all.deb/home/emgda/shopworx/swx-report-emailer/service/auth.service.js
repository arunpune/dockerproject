const apiService = require('./api.service');
const ApiService = apiService.ApiService;

class AuthService {
  constructor() {
    this.request = ApiService;
  }

  authenticate(data) {
    return this.request.post('/server/authenticate', data);
  }

  logout() {
    return this.request.get('/server/logout');
  }
}
module.exports.AuthService = new AuthService();

