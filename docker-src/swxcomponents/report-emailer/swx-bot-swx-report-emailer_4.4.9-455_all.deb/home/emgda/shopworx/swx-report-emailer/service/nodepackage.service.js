const bunyan = require('bunyan');
const axios = require('axios');
const EventEmitter = require('events');
const _ = require('lodash');
const prettyCron = require('prettycron');
const sancronos = require("sancronos-validator");
const schedule = require('node-schedule');
const fs = require('fs');
const moment = require('moment');
const nodemailer = require('nodemailer');
const request = require('request');

class NodePackage {
  constructor() {
    this.bunyan = bunyan;
    this.axios = axios;
    this.EventEmitter = EventEmitter;
    this._ = _;
    this.prettyCron = prettyCron;
    this.sancronos = sancronos;
    this.schedule = schedule;
    this.fs = fs;
    this.moment = moment;
    this.nodemailer = nodemailer;
    this.request = request;
  }
}
module.exports.NodePackage = new NodePackage();