let config = require('./config/config.json');

const nodePackage = require('./service/nodepackage.service');
const NodePackage = nodePackage.NodePackage;
const authJS = require('./utils/auth');
const utility = require('./utils/utility');

const elementService = require('./service/element.service').ElementService;

const bunyan = NodePackage.bunyan;
const _ = NodePackage._;
const prettyCron = NodePackage.prettyCron;
const schedule = NodePackage.schedule;
const sancronos = NodePackage.sancronos;
const nodemailer = NodePackage.nodemailer;
const moment = NodePackage.moment;
const request = NodePackage.request;
const fs = NodePackage.fs;


const log = bunyan.createLogger({ name: `index`, level: config.log.level });
const auth = authJS.auth(config, utility);

const outputDirectory = config.outputDirectory;
if (fs.existsSync(outputDirectory)) {
    log.error(`Output directory exists!`);
} else {
    log.error(`Output directory not found. Please provide correct path for output directory.`);
    process.exit(1);
}

auth.getAuthentication();

const partition = '-----------------------------------';
let siteid, sessionId = '';

let smtpConfig = {
    host: config.email.host,
    port: config.email.port,
    greetingTimeout: config.email.greetingTimeout,
    connectionTimeout: config.email.connectionTimeout,
    secure: config.email.secure, // use SSL
    auth: {
        user: config.email.user,
        pass: config.email.password
    }
};

// create reusable transporter object using the default SMTP transport
let transporter = nodemailer.createTransport(smtpConfig);

// setup e-mail data with unicode symbols
let mailOptions = {
    from: config.email.user, // sender address    
    text: config.email.text // plaintext body
};
/**
 * Authenticate before initialization
 */
authJS.emitter.on('init', (sessionid) => {
    log.error(`Authentication done successfully`);
    sessionId = sessionid;
    getUserDetails()
})

authJS.emitter.on('report', (sessionid) => {
    log.error(`Report Authentication done successfully`);
    sessionId = sessionid;
})

utility.emitter.on('sessionExpired', () => {
    log.error(`Session Expired trying to reAuthenticate`);
    auth.getAuthentication();
});

async function getUserDetails() {
    try {
        const response = await elementService.getUserDetails();
        const { status, data } = response;
        if (status === utility.HTTP_STATUS_CODE.SUCCESS && data) {
            siteid = data.results.activeSiteId;
            log.error('USER_FETCH: SUCCESS');
            log.error(partition);
            init();
        } else if (utility.checkSessionExpired(data)) {
            log.error(`Error while fetching user details: ${JSON.stringify(response.data)}`);
            // wait for execute next function call
            await new Promise(resolve => setTimeout(resolve, config.defaults.retry * 1000));
            setTimeout(() => getUserDetails(), 100);
        } else {
            log.error(`Error while fetching user details: ${JSON.stringify(response.data)}`);
        }
    } catch (error) {
        log.error(`Exception in fetch user details ${ex}`);
        await new Promise(resolve => setTimeout(resolve, retryServer * 1000));
        await getUserDetails();
    }
}

async function init() {
    try {
        let reports = config.reports;
        if (!reports || reports.length === 0) {
            log.error("No reports are configured on server. Exiting...");
            process.exit(1);
        } else {
            scheduleReports(reports)
        }
    } catch (error) {
        log.error("Error while validating configured reports, Error : " + error);
    }
}

async function scheduleReports(reportList) {
    try {
        log.error('Scheduling Reports.');
        let reportFound = false;
        // loop all returned reports
        _.forEach(reportList, function (reportObject) {
            // If report is active then execute report
            if (reportObject.active) {
                reportFound = true;
                log.error("|" + reportObject.reportname + "|" + reportObject.schedule + "|" + reportObject.format
                    + "|" + prettyCron.toString(reportObject.schedule));
                sancronos.isValid(reportObject.schedule, (error, crontab) => {
                    if (error) {
                        log.error('Invalid/ Incorrect CRON configured for Report with name: ' + reportObject.reportname + ', CRON: '
                            + reportObject.schedule);
                        process.exit(1);
                    } else {
                        schedule.scheduleJob(reportObject.schedule, () => {
                            log.error('Executing Report: ' + reportObject.reportname);
                            executeXLSReport(reportObject);
                        });
                    }
                });
            } else {
                log.error('Report with name: ' + reportObject.reportname + ' is not active.');
            }
        });
        if (reportFound == false) {
            log.error("No active report Schedule found in provisioning");
        }
    } catch (error) {
        log.error("Error while scheduling reports, Error : " + error);
    }
}

function executeReportApiURL(reportName, format) {
    let reportformat = "";
    if ('xls' === format) {
        reportformat = 'xlsdownloadreport';
    } else {
        log.error('Unknown format identified: ' + format + " for report name: " + reportName);
        log.error('Currently allowed formats: xls (all insmall case)');
        process.exit(1);
    }
    let retUrl = config.server.protocol + '://' + config.server.host + ':' + config.server.port + '/server/' + reportformat + '/'
        + reportName + '?' + '&all=true';
    //logger.info(retUrl);
    return retUrl;
}

function date(previousDay) {
    const year = parseInt(new Date(previousDay).getFullYear(), 10);
    const month = parseInt((new Date(previousDay)).getMonth() + 1, 10);
    const day = parseInt((new Date(previousDay).getDate()), 10);
    return parseInt(`${year}${String(month).padStart(2, '0')}${String(day).padStart(2, '0')}`, 10);
}

function getPreviousDay(date = new Date()) {
    const previous = new Date(date.getTime());
    previous.setDate(date.getDate() - 1);
    return previous;
}

/**
 * Execute XLS Report.
 * 
 * @param {object} reportObject 
 */
function executeXLSReport(reportObject) {
    try {
        const retUrl = executeReportApiURL(reportObject.reportname, reportObject.format);
        const previousDay = getPreviousDay();
        const currentTime = Date.now();
        const xlsFile = fs.createWriteStream(outputDirectory + reportObject.reportname + '_' + currentTime + '.xls');
        let errorFlag = false;
        const filters = {
            "siteid": siteid,
            "start": date(previousDay),
            "end": date(previousDay),
            "sublineIds": {},
        }
        request({
            url: retUrl,
            headers: {
                'content-type': 'application/json',
                'sessionId': sessionId
            },
            json: filters, method: 'POST'
        })
            .on('response', async function (response) {
                log.error("StatusCode: " + response.statusCode);
                if (response.statusCode !== 200) {
                    errorFlag = true;
                    log.error('Invalid session while fetching report');
                    await auth.getAuthentication(true);
                    // wait for execute next function call
                    await new Promise(resolve => setTimeout(resolve, config.defaults.retry * 1000));
                    setTimeout(() => executeXLSReport(reportObject), 100);
                }
                else if (response.headers['error-status'] == "true") {
                    log.error('Excel Response Error: ' + response.headers['response-log']);
                    log.error('Template Not Found');
                    errorFlag = true;
                } else {
                    errorFlag = false;
                }
            })
            .on('error', function (err) {
                errorFlag = true;
                log.error(err);
            })
            .pipe(xlsFile);

        xlsFile.on('finish', function () {
            log.error("Successfully completed writing xls File on Disk.");
            const filePath = `${outputDirectory}${reportObject.reportname}_${currentTime}.xls`
            if (!errorFlag) {
                let attachment = [];
                // send mail with defined transport object
                log.error("Sending xls file as it is to email recipients.");
                attachment = [
                    {
                        filename: reportObject.reportname + '_' + currentTime + ".xls",
                        path: filePath
                    }
                ]
                mail(reportObject, attachment, transporter, previousDay);
            }
            xlsFile.close();
            if (errorFlag) {
                fs.unlink(filePath, (err) => {
                    if (err) {
                        log.error("Error while deleting file: " + filePath + ", Error: " +
                            ((typeof err === 'object') ? JSON.stringify(err) : err));
                    } else {
                        log.error('Successfully deleted: ' + filePath);
                    }
                });
            }
        });
    } catch (error) {
        log.error("Error while executing xls report, Error : " + error);
    }
}

/**
 * Send mail.
 * 
 * @param {object} reportObject 
 * @param {array} attachment 
 * @param {object} transporter 
 * @param {object} filters 
 */
function mail(reportObject, attachment, transporter, previousDay) {
    try {
        let fromDate;
        if (previousDay) {
            fromDate = moment(previousDay).format(config.email.dateFormatForMailSubject);
        }

        mailOptions["attachments"] = attachment;
        _.forEach(config.emailidlist, function (emailList) {
            if (emailList.reportname == reportObject.reportname) {
                log.error(emailList.ids)
                mailOptions["to"] = emailList.ids;
                mailOptions["subject"] = config.email.mailSubjectShopWorx + ' ' + reportObject.reportdescription +
                    ' ' + config.email.mailSubjectReport + ' ' + config.email.mailSubjectSeperator + ' ' +
                    config.email.mailSubjectFrom + ': ' + fromDate + ' ' + config.email.mailSubjectTo + ': ' + fromDate;

                log.error(mailOptions);
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        log.error('Error sending message sent for Report: ' + reportObject.reportdescription);
                        log.error(error);
                        retry(mailOptions, 5);
                    } else {
                        attachment.forEach((obj) => {
                            let file = obj.path;
                            fs.unlink(file, (err) => {
                                if (err) {
                                    log.error("Error while deleting file: " + file + ", Error: " +
                                        ((typeof err === 'object') ? JSON.stringify(err) : err));
                                } else {
                                    log.error('Successfully deleted: ' + file);
                                }
                            });
                        });
                        log.error('Message sent for Report: ' + reportObject.reportdescription +
                            ", Email Server Response: " + info.response);
                    }
                });
            }
        });
    } catch (error) {
        log.error("Error while sending email, Error : " + error);
    }
}

/**
 * Retry for given number of times when the First attempt to send email fails.
 * 
 * @param {object} mailOptions 
 * @param {number} count 
 */
function retry(mailOptions, count) {
    try {
        let response = 0;
        // count = 5;
        //while(count >0){
        log.error(mailOptions);
        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                log.error("message sending fail for " + mailOptions["subject"]);
                log.error("Again retry for " + count + " times");
                log.error(error);
                response = 0;
                if (count > 0) {
                    count = count - 1;
                    retry(mailOptions, count);
                }
            } else {
                log.error('Message sent for ***** : ' + mailOptions["subject"] + info.response);
                response = 1;
                return response;
            }
        });
    } catch (error) {
        log.error("Error while retry in sending email, Error : " + error);
    }
}