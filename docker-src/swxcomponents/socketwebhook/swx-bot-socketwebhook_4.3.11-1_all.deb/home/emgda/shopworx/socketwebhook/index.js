
/**
 * @author Hrushikesh (hpatil@entrib.com)
 * modified by @author Vishal (vbhosale@entrib.com)
 * 
 */

let bodyParser = require('body-parser');
let app = require('express')();
let server = require('http').Server(app);
let io = require('socket.io')(server);
const bunyan = require('bunyan');
let config = require('./config.json');
const defaults = config.defaults;
const log = bunyan.createLogger({ name: 'socketwebhook', level: 20 });
if (typeof config.socketport != 'number') {
    log.fatal(`Data type for configuration parameter 'socketport' must be: number`);
    process.exit(1);
}
server.listen(config.socketport, function () {
    let host = server.address().address;
    let port = server.address().port;
    log.info('Example app listening at http://%s:%s', host, port);
});
// added variables
let localCache = {};
let onStartUp = false;
let retryTime = defaults.eventresendTime || 5000; // in milliseconds
let maxRetry = defaults.maxEventRetryCount || 5; // in number
let eventpollingtime = defaults.eventpollingtime || 1000; // in milliseconds
// end
io.sockets.on('connection', function (socket) {
    log.info('Connected');
});
// default for server socketwebhook events.
generateEvents('update',io);

for(let i = 0; i < config.namespaces.length; i++){
    let namespace = config.namespaces[i].name;
    let socketNamespace = io.of(namespace);
    // code for planeventack namespace for checking plan event receive response from PEA
    if(namespace == 'planeventack') {
       ackEvents(namespace, socketNamespace);
    } else {
       generateEvents(namespace,socketNamespace)
    }
}
// This function emits the data over socket. It is generic for all namespace
function generateEvents(namespace,socketNamespace){
    log.info("------------ %s",namespace,"-------------");
    socketNamespace.on('connection', function (socket) {
        log.info('Connected %',namespace);
    });

    app.post('/'+namespace+'/:eventName', function(req,res){
            let body = '';
            req.on('data', function (data) {
                body += data;
                // Too much POST data, kill the connection!
                // 2e6 === 2 * Math.pow(10, 6) === 2 * 1000000 ~~~ 1MB
                if (body.length > 2e6)
                    req.connection.destroy();
            });

            req.on('end', function () {
                try {
                    let eventName = req.params.eventName;
                    log.info(namespace ," event name %s" , req.params.eventName);
                    let postData = JSON.parse(body);
                    // add emitid, retrycount and lastsendtime. emitid is combination of planid and currenttimestamp
                    if(postData.elementName=='planning'){
                       let now = new Date().valueOf();
                       postData.emitid = postData.planid + '_' + now;
                       localCache[postData.emitid] = postData;
                       localCache[postData.emitid].retrycount = 0;
                       localCache[postData.emitid].lastsendtime = now;
                   }
                   if(!onStartUp) {
                       pollEvents(namespace, eventName, socketNamespace);
                   }
                    socketNamespace.emit(namespace+'_' + eventName, postData);
                } catch(exception){
                    log.info("Exception in ", namespace ," socket event %s ",exception);
                }
            });
        res.send('success');
    });
}
/**
 * This method is used for listen the plan event response
 * @param {*} namespace 
 * @param {*} socketNamespace 
 */
// This function emits the data over socket. It is generic for all namespace
function ackEvents(namespace,socketNamespace){
   socketNamespace.on('connection', function (socket) {
       log.info('Connected %',namespace);
   });
   app.post('/'+namespace+'/:eventName', function(req,res){
           let body = '';
           req.on('data', function (data) {
               body += data;
               if (body.length > 2e6)
                   req.connection.destroy();
           });

           req.on('end', function () {
               try {
                   let postData = JSON.parse(body);
                   if(localCache[postData.emitid]) {
                       log.error('on response delete emitid from localCache ', JSON.stringify(postData));
                       delete localCache[postData.emitid];
                   }
               } catch(exception){
                   log.info("Exception in ", namespace ," socket event %s ",exception);
               }
           });
       res.send('success');
   });
}
/**
 * This method check the any planning event pending or not
 * @param {String} namespace 
 * @param {String} eventName 
 * @param {String} socketNamespace 
 */
function pollEvents(namespace, eventName, socketNamespace) {
   let now = new Date().valueOf();
   try {
       for(let i in localCache) {
           let obj = localCache[i];
           let diff = now - obj.lastsendtime 
           if(diff > retryTime && obj.retrycount <= maxRetry) {
               localCache[i].lastsendtime = now;
               localCache[i].retrycount++;
               log.info('Resent data ', JSON.stringify(obj));
               socketNamespace.emit(namespace+'_' + eventName, obj);
           } if(obj.retrycount >= maxRetry) {
               log.error('delete emitid from localCache after maxretry ', JSON.stringify(obj));
               // TODO write data to SWX after max retry
               delete localCache[obj.emitid];
           }
       }
   } catch(ex) {
       log.error(`Exception in emitting event ${ex}`);
   }
   setTimeout(()=> {
       pollEvents(namespace, eventName, socketNamespace)
   }, eventpollingtime);
}