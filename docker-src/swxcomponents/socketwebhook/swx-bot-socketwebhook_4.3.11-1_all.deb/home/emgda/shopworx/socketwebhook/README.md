# README #

NodeJS based Socketwebhook Infrastructure for ShopWorx

### What is this repository for? ###

* This contains the socketwebhook (nodejs based) service for ShopWorx. Typically the server would send Element writes/updates on to a provisioned socket. This would then use the nodejs emitter to emit data to other services that need the information.

### How do I get set up? ###

* Setup

```
#!shellscript
git pull
npm install
```

 
# Configuration parameters description 

| Configuration parameter   | Description           | Default value     | Examples         |
| :-------------------------|:----------------------| :-----------------| :----------------|
| `socketport` | Socketwebhook portnumber | 10190  | 10190
| `namespaces.analyzer` | This namespace used for 2.8 Pre Analyzer E.A. | `analyzer`  | `analyzer`
| `namespaces.nodemonit` | This namespace used for 2.8 Pre Analyzer E.A. | `nodemonit`  | `nodemonit`
| `namespaces.linemes` | This namespace used for Line MES for ACK to PLC (i.e. PLC Write) | `linemes`  | `linemes`
| `namespaces.planeventack` | This namespace used for listening the planning event response from PEA | `planeventack`  | `planeventack`
| `defaults.eventresendTime` | Time to wait for send event after same previous event send. It is in milliseconds | 5000  | 5000
| `defaults.maxEventRetryCount` | maxEventRetryCount in number | 5  | 5
| `defaults.eventpollingtime` | Polling time to check the pending events after every configurable milliseconds | 1000  | 1000

* Dependencies
Node
* Database configuration
Needs provisioning in Postgres for specific element data to be received.

* Deployment instructions



### Contribution guidelines ###

* Javascript coding guidelines

### Who do I talk to? ###

* Repo owner or admin or developer
* psingh@entrib.com or jbhatia@entrib.com